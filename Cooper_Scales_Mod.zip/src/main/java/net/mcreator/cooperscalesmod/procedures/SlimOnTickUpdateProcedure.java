package net.mcreator.cooperscalesmod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.cooperscalesmod.init.CooperScalesModModBlocks;

public class SlimOnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world.getBlockState(BlockPos.containing(x + 1, y + 0, z + 0)).canOcclude()) {
			world.setBlock(BlockPos.containing(x + 1, y + 0, z + 0), CooperScalesModModBlocks.SLIM.get().defaultBlockState(), 3);
		}
		if (world.getBlockState(BlockPos.containing(x + -1, y + 0, z + 0)).canOcclude()) {
			world.setBlock(BlockPos.containing(x + -1, y + 0, z + 0), CooperScalesModModBlocks.SLIM.get().defaultBlockState(), 3);
		}
		if (world.getBlockState(BlockPos.containing(x + 0, y + 1, z + 0)).canOcclude()) {
			world.setBlock(BlockPos.containing(x + 0, y + 1, z + 0), CooperScalesModModBlocks.SLIM.get().defaultBlockState(), 3);
		}
		if (world.getBlockState(BlockPos.containing(x + 0, y + -1, z + 0)).canOcclude()) {
			world.setBlock(BlockPos.containing(x + 0, y + -1, z + 0), CooperScalesModModBlocks.SLIM.get().defaultBlockState(), 3);
		}
		if (world.getBlockState(BlockPos.containing(x + 0, y + 0, z + 1)).canOcclude()) {
			world.setBlock(BlockPos.containing(x + 0, y + 0, z + 1), CooperScalesModModBlocks.SLIM.get().defaultBlockState(), 3);
		}
		if (world.getBlockState(BlockPos.containing(x + 0, y + 0, z + -1)).canOcclude()) {
			world.setBlock(BlockPos.containing(x + 0, y + 0, z + -1), CooperScalesModModBlocks.SLIM.get().defaultBlockState(), 3);
		}
	}
}
