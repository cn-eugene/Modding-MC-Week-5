
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cooperscalesmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.cooperscalesmod.block.SlimBlock;
import net.mcreator.cooperscalesmod.block.MushoomBlock;
import net.mcreator.cooperscalesmod.block.IradiumBlock;
import net.mcreator.cooperscalesmod.block.DarkdarkPortalBlock;
import net.mcreator.cooperscalesmod.block.BonosbaroBlock;
import net.mcreator.cooperscalesmod.block.BlokBlock;
import net.mcreator.cooperscalesmod.CooperScalesModMod;

public class CooperScalesModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, CooperScalesModMod.MODID);
	public static final RegistryObject<Block> BONOSBARO = REGISTRY.register("bonosbaro", () -> new BonosbaroBlock());
	public static final RegistryObject<Block> IRADIUM = REGISTRY.register("iradium", () -> new IradiumBlock());
	public static final RegistryObject<Block> SLIM = REGISTRY.register("slim", () -> new SlimBlock());
	public static final RegistryObject<Block> MUSHOOM = REGISTRY.register("mushoom", () -> new MushoomBlock());
	public static final RegistryObject<Block> DARKDARK_PORTAL = REGISTRY.register("darkdark_portal", () -> new DarkdarkPortalBlock());
	public static final RegistryObject<Block> BLOK = REGISTRY.register("blok", () -> new BlokBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
