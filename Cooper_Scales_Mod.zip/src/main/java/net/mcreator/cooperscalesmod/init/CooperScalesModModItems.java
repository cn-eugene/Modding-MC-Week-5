
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cooperscalesmod.init;

import org.checkerframework.checker.units.qual.C;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.cooperscalesmod.item.SapppItem;
import net.mcreator.cooperscalesmod.item.SapcItem;
import net.mcreator.cooperscalesmod.item.SaparwItem;
import net.mcreator.cooperscalesmod.item.OoItem;
import net.mcreator.cooperscalesmod.item.MushoomsapItem;
import net.mcreator.cooperscalesmod.item.IsItem;
import net.mcreator.cooperscalesmod.item.IreiItem;
import net.mcreator.cooperscalesmod.item.IredemoreItem;
import net.mcreator.cooperscalesmod.item.IrecItem;
import net.mcreator.cooperscalesmod.item.IreItem;
import net.mcreator.cooperscalesmod.item.IradiumarmorItem;
import net.mcreator.cooperscalesmod.item.HItem;
import net.mcreator.cooperscalesmod.item.DarkdarkItem;
import net.mcreator.cooperscalesmod.item.CItem;
import net.mcreator.cooperscalesmod.CooperScalesModMod;

public class CooperScalesModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, CooperScalesModMod.MODID);
	public static final RegistryObject<Item> BONOSBARO = block(CooperScalesModModBlocks.BONOSBARO);
	public static final RegistryObject<Item> IRADIUM = block(CooperScalesModModBlocks.IRADIUM);
	public static final RegistryObject<Item> IREDEMORE = REGISTRY.register("iredemore", () -> new IredemoreItem());
	public static final RegistryObject<Item> IRE = REGISTRY.register("ire", () -> new IreItem());
	public static final RegistryObject<Item> IREI = REGISTRY.register("irei", () -> new IreiItem());
	public static final RegistryObject<Item> IS = REGISTRY.register("is", () -> new IsItem());
	public static final RegistryObject<Item> IREC = REGISTRY.register("irec", () -> new IrecItem());
	public static final RegistryObject<Item> IRADIUMARMOR_HELMET = REGISTRY.register("iradiumarmor_helmet", () -> new IradiumarmorItem.Helmet());
	public static final RegistryObject<Item> IRADIUMARMOR_CHESTPLATE = REGISTRY.register("iradiumarmor_chestplate", () -> new IradiumarmorItem.Chestplate());
	public static final RegistryObject<Item> IRADIUMARMOR_LEGGINGS = REGISTRY.register("iradiumarmor_leggings", () -> new IradiumarmorItem.Leggings());
	public static final RegistryObject<Item> IRADIUMARMOR_BOOTS = REGISTRY.register("iradiumarmor_boots", () -> new IradiumarmorItem.Boots());
	public static final RegistryObject<Item> THUP_SPAWN_EGG = REGISTRY.register("thup_spawn_egg", () -> new ForgeSpawnEggItem(CooperScalesModModEntities.THUP, -6750055, -65281, new Item.Properties()));
	public static final RegistryObject<Item> C = REGISTRY.register("c", () -> new CItem());
	public static final RegistryObject<Item> OO_HELMET = REGISTRY.register("oo_helmet", () -> new OoItem.Helmet());
	public static final RegistryObject<Item> OO_CHESTPLATE = REGISTRY.register("oo_chestplate", () -> new OoItem.Chestplate());
	public static final RegistryObject<Item> OO_LEGGINGS = REGISTRY.register("oo_leggings", () -> new OoItem.Leggings());
	public static final RegistryObject<Item> OO_BOOTS = REGISTRY.register("oo_boots", () -> new OoItem.Boots());
	public static final RegistryObject<Item> FJ_SPAWN_EGG = REGISTRY.register("fj_spawn_egg", () -> new ForgeSpawnEggItem(CooperScalesModModEntities.FJ, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> STEVE_SPAWN_EGG = REGISTRY.register("steve_spawn_egg", () -> new ForgeSpawnEggItem(CooperScalesModModEntities.STEVE, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> SLIM = block(CooperScalesModModBlocks.SLIM);
	public static final RegistryObject<Item> MUSHOOMSAP = REGISTRY.register("mushoomsap", () -> new MushoomsapItem());
	public static final RegistryObject<Item> SAPARW = REGISTRY.register("saparw", () -> new SaparwItem());
	public static final RegistryObject<Item> H = REGISTRY.register("h", () -> new HItem());
	public static final RegistryObject<Item> MUSHOOM = block(CooperScalesModModBlocks.MUSHOOM);
	public static final RegistryObject<Item> DARKDARK = REGISTRY.register("darkdark", () -> new DarkdarkItem());
	public static final RegistryObject<Item> SAPC = REGISTRY.register("sapc", () -> new SapcItem());
	public static final RegistryObject<Item> BLOK = block(CooperScalesModModBlocks.BLOK);
	public static final RegistryObject<Item> SAPPP_HELMET = REGISTRY.register("sappp_helmet", () -> new SapppItem.Helmet());
	public static final RegistryObject<Item> SAPPP_CHESTPLATE = REGISTRY.register("sappp_chestplate", () -> new SapppItem.Chestplate());
	public static final RegistryObject<Item> SAPPP_LEGGINGS = REGISTRY.register("sappp_leggings", () -> new SapppItem.Leggings());
	public static final RegistryObject<Item> SAPPP_BOOTS = REGISTRY.register("sappp_boots", () -> new SapppItem.Boots());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
