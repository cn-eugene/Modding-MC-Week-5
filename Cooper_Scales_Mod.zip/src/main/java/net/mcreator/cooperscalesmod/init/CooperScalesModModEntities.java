
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cooperscalesmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.cooperscalesmod.entity.ThupEntity;
import net.mcreator.cooperscalesmod.entity.SteveEntity;
import net.mcreator.cooperscalesmod.entity.FjEntityProjectile;
import net.mcreator.cooperscalesmod.entity.FjEntity;
import net.mcreator.cooperscalesmod.entity.FEntity;
import net.mcreator.cooperscalesmod.entity.ArowEntity;
import net.mcreator.cooperscalesmod.CooperScalesModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CooperScalesModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CooperScalesModMod.MODID);
	public static final RegistryObject<EntityType<ThupEntity>> THUP = register("thup",
			EntityType.Builder.<ThupEntity>of(ThupEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ThupEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<FEntity>> F = register("f",
			EntityType.Builder.<FEntity>of(FEntity::new, MobCategory.MISC).setCustomClientFactory(FEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<FjEntity>> FJ = register("fj",
			EntityType.Builder.<FjEntity>of(FjEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FjEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<FjEntityProjectile>> FJ_PROJECTILE = register("projectile_fj",
			EntityType.Builder.<FjEntityProjectile>of(FjEntityProjectile::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).setCustomClientFactory(FjEntityProjectile::new).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<SteveEntity>> STEVE = register("steve",
			EntityType.Builder.<SteveEntity>of(SteveEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SteveEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ArowEntity>> AROW = register("arow",
			EntityType.Builder.<ArowEntity>of(ArowEntity::new, MobCategory.MISC).setCustomClientFactory(ArowEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			ThupEntity.init();
			FjEntity.init();
			SteveEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(THUP.get(), ThupEntity.createAttributes().build());
		event.put(FJ.get(), FjEntity.createAttributes().build());
		event.put(STEVE.get(), SteveEntity.createAttributes().build());
	}
}
