
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cooperscalesmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.cooperscalesmod.client.renderer.ThupRenderer;
import net.mcreator.cooperscalesmod.client.renderer.SteveRenderer;
import net.mcreator.cooperscalesmod.client.renderer.FjRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CooperScalesModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(CooperScalesModModEntities.THUP.get(), ThupRenderer::new);
		event.registerEntityRenderer(CooperScalesModModEntities.F.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(CooperScalesModModEntities.FJ.get(), FjRenderer::new);
		event.registerEntityRenderer(CooperScalesModModEntities.FJ_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(CooperScalesModModEntities.STEVE.get(), SteveRenderer::new);
		event.registerEntityRenderer(CooperScalesModModEntities.AROW.get(), ThrownItemRenderer::new);
	}
}
