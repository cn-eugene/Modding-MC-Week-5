
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cooperscalesmod.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.cooperscalesmod.CooperScalesModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CooperScalesModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CooperScalesModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(CooperScalesModModBlocks.BONOSBARO.get().asItem());
			tabData.accept(CooperScalesModModItems.IRE.get());
			tabData.accept(CooperScalesModModItems.IS.get());
			tabData.accept(CooperScalesModModItems.IREC.get());
			tabData.accept(CooperScalesModModItems.IRADIUMARMOR_HELMET.get());
			tabData.accept(CooperScalesModModItems.IRADIUMARMOR_CHESTPLATE.get());
			tabData.accept(CooperScalesModModItems.IRADIUMARMOR_LEGGINGS.get());
			tabData.accept(CooperScalesModModItems.IRADIUMARMOR_BOOTS.get());
			tabData.accept(CooperScalesModModItems.C.get());
			tabData.accept(CooperScalesModModItems.OO_HELMET.get());
			tabData.accept(CooperScalesModModItems.OO_CHESTPLATE.get());
			tabData.accept(CooperScalesModModItems.OO_LEGGINGS.get());
			tabData.accept(CooperScalesModModItems.OO_BOOTS.get());
			tabData.accept(CooperScalesModModBlocks.SLIM.get().asItem());
			tabData.accept(CooperScalesModModItems.SAPARW.get());
			tabData.accept(CooperScalesModModItems.H.get());
			tabData.accept(CooperScalesModModItems.SAPC.get());
			tabData.accept(CooperScalesModModItems.SAPPP_HELMET.get());
			tabData.accept(CooperScalesModModItems.SAPPP_CHESTPLATE.get());
			tabData.accept(CooperScalesModModItems.SAPPP_LEGGINGS.get());
			tabData.accept(CooperScalesModModItems.SAPPP_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(CooperScalesModModItems.THUP_SPAWN_EGG.get());
			tabData.accept(CooperScalesModModItems.FJ_SPAWN_EGG.get());
			tabData.accept(CooperScalesModModItems.STEVE_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(CooperScalesModModItems.IREDEMORE.get());
			tabData.accept(CooperScalesModModItems.IREI.get());
			tabData.accept(CooperScalesModModItems.MUSHOOMSAP.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(CooperScalesModModBlocks.IRADIUM.get().asItem());
			tabData.accept(CooperScalesModModBlocks.MUSHOOM.get().asItem());
			tabData.accept(CooperScalesModModBlocks.BLOK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(CooperScalesModModItems.DARKDARK.get());
		}
	}
}
