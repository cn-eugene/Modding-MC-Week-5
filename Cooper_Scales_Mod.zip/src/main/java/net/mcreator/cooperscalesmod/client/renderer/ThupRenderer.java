
package net.mcreator.cooperscalesmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.cooperscalesmod.entity.ThupEntity;

public class ThupRenderer extends HumanoidMobRenderer<ThupEntity, HumanoidModel<ThupEntity>> {
	public ThupRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.6f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(ThupEntity entity) {
		return new ResourceLocation("cooper_scales_mod:textures/entities/2024_07_15_new-dark-herobrine-22695934.png");
	}

	@Override
	protected boolean isShaking(ThupEntity entity) {
		return true;
	}
}
