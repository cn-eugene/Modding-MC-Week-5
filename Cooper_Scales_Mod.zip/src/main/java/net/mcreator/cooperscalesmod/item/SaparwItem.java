
package net.mcreator.cooperscalesmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SaparwItem extends Item {
	public SaparwItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
