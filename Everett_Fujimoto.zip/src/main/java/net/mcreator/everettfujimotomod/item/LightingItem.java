
package net.mcreator.everettfujimotomod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LightingItem extends Item {
	public LightingItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.EPIC));
	}
}
