package net.mcreator.everettfujimotomod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;

import net.mcreator.everettfujimotomod.EverettFujimotoModMod;

public class NukeRedstoneOnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		EverettFujimotoModMod.queueServerWork(60, () -> {
			if (world instanceof Level _level && !_level.isClientSide())
				_level.explode(null, x, y, z, 100, Level.ExplosionInteraction.TNT);
		});
	}
}
