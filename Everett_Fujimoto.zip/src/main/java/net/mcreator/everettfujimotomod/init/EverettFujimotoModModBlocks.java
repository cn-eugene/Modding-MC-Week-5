
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.everettfujimotomod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.everettfujimotomod.block.NukeBlock;
import net.mcreator.everettfujimotomod.block.LIGHTINGOREBlock;
import net.mcreator.everettfujimotomod.EverettFujimotoModMod;

public class EverettFujimotoModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, EverettFujimotoModMod.MODID);
	public static final RegistryObject<Block> NUKE = REGISTRY.register("nuke", () -> new NukeBlock());
	public static final RegistryObject<Block> LIGHTINGORE = REGISTRY.register("lightingore", () -> new LIGHTINGOREBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
