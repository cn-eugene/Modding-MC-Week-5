
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.everettfujimotomod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.everettfujimotomod.entity.TntarrowEntity;
import net.mcreator.everettfujimotomod.entity.TEST2Entity;
import net.mcreator.everettfujimotomod.entity.NinjastarEntity;
import net.mcreator.everettfujimotomod.entity.Ninja2Entity;
import net.mcreator.everettfujimotomod.entity.Firestar2Entity;
import net.mcreator.everettfujimotomod.entity.FireninjastarEntity;
import net.mcreator.everettfujimotomod.EverettFujimotoModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EverettFujimotoModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, EverettFujimotoModMod.MODID);
	public static final RegistryObject<EntityType<TntarrowEntity>> TNTARROW = register("tntarrow",
			EntityType.Builder.<TntarrowEntity>of(TntarrowEntity::new, MobCategory.MISC).setCustomClientFactory(TntarrowEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<NinjastarEntity>> NINJASTAR = register("ninjastar",
			EntityType.Builder.<NinjastarEntity>of(NinjastarEntity::new, MobCategory.MISC).setCustomClientFactory(NinjastarEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<TEST2Entity>> TEST_2 = register("test_2",
			EntityType.Builder.<TEST2Entity>of(TEST2Entity::new, MobCategory.MISC).setCustomClientFactory(TEST2Entity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<Ninja2Entity>> NINJA_2 = register("ninja_2",
			EntityType.Builder.<Ninja2Entity>of(Ninja2Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(100).setUpdateInterval(3).setCustomClientFactory(Ninja2Entity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<FireninjastarEntity>> FIRENINJASTAR = register("fireninjastar",
			EntityType.Builder.<FireninjastarEntity>of(FireninjastarEntity::new, MobCategory.MISC).setCustomClientFactory(FireninjastarEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<Firestar2Entity>> FIRESTAR_2 = register("firestar_2",
			EntityType.Builder.<Firestar2Entity>of(Firestar2Entity::new, MobCategory.MISC).setCustomClientFactory(Firestar2Entity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			Ninja2Entity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(NINJA_2.get(), Ninja2Entity.createAttributes().build());
	}
}
