
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.everettfujimotomod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.everettfujimotomod.client.renderer.Ninja2Renderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class EverettFujimotoModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(EverettFujimotoModModEntities.TNTARROW.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EverettFujimotoModModEntities.NINJASTAR.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EverettFujimotoModModEntities.TEST_2.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EverettFujimotoModModEntities.NINJA_2.get(), Ninja2Renderer::new);
		event.registerEntityRenderer(EverettFujimotoModModEntities.FIRENINJASTAR.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EverettFujimotoModModEntities.FIRESTAR_2.get(), ThrownItemRenderer::new);
	}
}
