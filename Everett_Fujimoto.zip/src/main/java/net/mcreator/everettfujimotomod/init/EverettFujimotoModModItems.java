
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.everettfujimotomod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.everettfujimotomod.item.TntbowItem;
import net.mcreator.everettfujimotomod.item.TntItem;
import net.mcreator.everettfujimotomod.item.THORSHAMMERItem;
import net.mcreator.everettfujimotomod.item.TESTItem;
import net.mcreator.everettfujimotomod.item.SpickyarmorItem;
import net.mcreator.everettfujimotomod.item.NinjaItem;
import net.mcreator.everettfujimotomod.item.LightinghoeItem;
import net.mcreator.everettfujimotomod.item.LightingItem;
import net.mcreator.everettfujimotomod.item.LgihtinghoeItem;
import net.mcreator.everettfujimotomod.item.LIGHTINGAXEItem;
import net.mcreator.everettfujimotomod.item.Firestartest1Item;
import net.mcreator.everettfujimotomod.item.FirestarItem;
import net.mcreator.everettfujimotomod.EverettFujimotoModMod;

public class EverettFujimotoModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EverettFujimotoModMod.MODID);
	public static final RegistryObject<Item> NUKE = block(EverettFujimotoModModBlocks.NUKE);
	public static final RegistryObject<Item> LIGHTING = REGISTRY.register("lighting", () -> new LightingItem());
	public static final RegistryObject<Item> LIGHTINGORE = block(EverettFujimotoModModBlocks.LIGHTINGORE);
	public static final RegistryObject<Item> THORSHAMMER = REGISTRY.register("thorshammer", () -> new THORSHAMMERItem());
	public static final RegistryObject<Item> LIGHTINGAXE = REGISTRY.register("lightingaxe", () -> new LIGHTINGAXEItem());
	public static final RegistryObject<Item> LIGHTINGHOE = REGISTRY.register("lightinghoe", () -> new LightinghoeItem());
	public static final RegistryObject<Item> LGIHTINGHOE = REGISTRY.register("lgihtinghoe", () -> new LgihtinghoeItem());
	public static final RegistryObject<Item> TNTBOW = REGISTRY.register("tntbow", () -> new TntbowItem());
	public static final RegistryObject<Item> SPICKYARMOR_HELMET = REGISTRY.register("spickyarmor_helmet", () -> new SpickyarmorItem.Helmet());
	public static final RegistryObject<Item> SPICKYARMOR_CHESTPLATE = REGISTRY.register("spickyarmor_chestplate", () -> new SpickyarmorItem.Chestplate());
	public static final RegistryObject<Item> SPICKYARMOR_LEGGINGS = REGISTRY.register("spickyarmor_leggings", () -> new SpickyarmorItem.Leggings());
	public static final RegistryObject<Item> SPICKYARMOR_BOOTS = REGISTRY.register("spickyarmor_boots", () -> new SpickyarmorItem.Boots());
	public static final RegistryObject<Item> TNT = REGISTRY.register("tnt", () -> new TntItem());
	public static final RegistryObject<Item> NINJA = REGISTRY.register("ninja", () -> new NinjaItem());
	public static final RegistryObject<Item> TEST = REGISTRY.register("test", () -> new TESTItem());
	public static final RegistryObject<Item> NINJA_2_SPAWN_EGG = REGISTRY.register("ninja_2_spawn_egg", () -> new ForgeSpawnEggItem(EverettFujimotoModModEntities.NINJA_2, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> FIRESTAR = REGISTRY.register("firestar", () -> new FirestarItem());
	public static final RegistryObject<Item> FIRESTARTEST_1 = REGISTRY.register("firestartest_1", () -> new Firestartest1Item());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
