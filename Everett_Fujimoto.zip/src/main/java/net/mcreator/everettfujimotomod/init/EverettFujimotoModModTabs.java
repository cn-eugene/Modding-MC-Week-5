
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.everettfujimotomod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.everettfujimotomod.EverettFujimotoModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EverettFujimotoModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EverettFujimotoModMod.MODID);
	public static final RegistryObject<CreativeModeTab> ATAB = REGISTRY.register("atab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.everett_fujimoto_mod.atab")).icon(() -> new ItemStack(EverettFujimotoModModItems.NINJA.get())).displayItems((parameters, tabData) -> {
				tabData.accept(EverettFujimotoModModBlocks.NUKE.get().asItem());
				tabData.accept(EverettFujimotoModModItems.LIGHTING.get());
				tabData.accept(EverettFujimotoModModBlocks.LIGHTINGORE.get().asItem());
				tabData.accept(EverettFujimotoModModItems.THORSHAMMER.get());
				tabData.accept(EverettFujimotoModModItems.LIGHTINGAXE.get());
				tabData.accept(EverettFujimotoModModItems.LIGHTINGHOE.get());
				tabData.accept(EverettFujimotoModModItems.LGIHTINGHOE.get());
				tabData.accept(EverettFujimotoModModItems.TNTBOW.get());
				tabData.accept(EverettFujimotoModModItems.SPICKYARMOR_HELMET.get());
				tabData.accept(EverettFujimotoModModItems.SPICKYARMOR_CHESTPLATE.get());
				tabData.accept(EverettFujimotoModModItems.SPICKYARMOR_LEGGINGS.get());
				tabData.accept(EverettFujimotoModModItems.SPICKYARMOR_BOOTS.get());
				tabData.accept(EverettFujimotoModModItems.TNT.get());
				tabData.accept(EverettFujimotoModModItems.NINJA.get());
				tabData.accept(EverettFujimotoModModItems.FIRESTARTEST_1.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(EverettFujimotoModModItems.TEST.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(EverettFujimotoModModItems.NINJA_2_SPAWN_EGG.get());
		}
	}
}
