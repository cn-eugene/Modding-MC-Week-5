
package net.mcreator.maxwellnicholsmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class Dream2ndformItem extends Item {
	public Dream2ndformItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
