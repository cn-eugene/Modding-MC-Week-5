
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.maxwellnicholsmod.init;

import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class MaxwellNicholsModModTrades {
}
