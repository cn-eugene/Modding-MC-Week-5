
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maxwellnicholsmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.maxwellnicholsmod.item.UhhhhhItem;
import net.mcreator.maxwellnicholsmod.item.NINJAItem;
import net.mcreator.maxwellnicholsmod.item.Entity30Item;
import net.mcreator.maxwellnicholsmod.item.DreamItem;
import net.mcreator.maxwellnicholsmod.item.Dream2ndformItem;
import net.mcreator.maxwellnicholsmod.MaxwellNicholsModMod;

public class MaxwellNicholsModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MaxwellNicholsModMod.MODID);
	public static final RegistryObject<Item> DREAMCOMEBACK = block(MaxwellNicholsModModBlocks.DREAMCOMEBACK);
	public static final RegistryObject<Item> DREAM_2NDFORM = REGISTRY.register("dream_2ndform", () -> new Dream2ndformItem());
	public static final RegistryObject<Item> DREAM = REGISTRY.register("dream", () -> new DreamItem());
	public static final RegistryObject<Item> UHHHHH = REGISTRY.register("uhhhhh", () -> new UhhhhhItem());
	public static final RegistryObject<Item> ENDY_SPAWN_EGG = REGISTRY.register("endy_spawn_egg", () -> new ForgeSpawnEggItem(MaxwellNicholsModModEntities.ENDY, -39322, -3394816, new Item.Properties()));
	public static final RegistryObject<Item> ENTITY_303_SPAWN_EGG = REGISTRY.register("entity_303_spawn_egg", () -> new ForgeSpawnEggItem(MaxwellNicholsModModEntities.ENTITY_303, -16777012, -3394816, new Item.Properties()));
	public static final RegistryObject<Item> NINJA = REGISTRY.register("ninja", () -> new NINJAItem());
	public static final RegistryObject<Item> ENTITY_30 = REGISTRY.register("entity_30", () -> new Entity30Item());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
