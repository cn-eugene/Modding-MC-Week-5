
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maxwellnicholsmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.maxwellnicholsmod.block.DreamcomebackBlock;
import net.mcreator.maxwellnicholsmod.MaxwellNicholsModMod;

public class MaxwellNicholsModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MaxwellNicholsModMod.MODID);
	public static final RegistryObject<Block> DREAMCOMEBACK = REGISTRY.register("dreamcomeback", () -> new DreamcomebackBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
