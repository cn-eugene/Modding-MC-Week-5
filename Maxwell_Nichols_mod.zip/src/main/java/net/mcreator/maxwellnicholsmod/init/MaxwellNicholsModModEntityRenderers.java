
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maxwellnicholsmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.maxwellnicholsmod.client.renderer.Entity303Renderer;
import net.mcreator.maxwellnicholsmod.client.renderer.EndyRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MaxwellNicholsModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MaxwellNicholsModModEntities.ENDY.get(), EndyRenderer::new);
		event.registerEntityRenderer(MaxwellNicholsModModEntities.ENTITY_303.get(), Entity303Renderer::new);
		event.registerEntityRenderer(MaxwellNicholsModModEntities.NINJA_2.get(), ThrownItemRenderer::new);
	}
}
