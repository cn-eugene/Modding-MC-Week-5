
package net.mcreator.annasutherlandmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.annasutherlandmod.entity.GtrEntity;

public class GtrRenderer extends HumanoidMobRenderer<GtrEntity, HumanoidModel<GtrEntity>> {
	public GtrRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(GtrEntity entity) {
		return new ResourceLocation("anna_sutherland_mod:textures/entities/201278d1bd4fa733ab8a97865683e0b5ff6ce8a7.png");
	}
}
