
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.annasutherlandmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.annasutherlandmod.block.TheimpossibleBlock;
import net.mcreator.annasutherlandmod.block.RedBlock;
import net.mcreator.annasutherlandmod.AnnaSutherlandModMod;

public class AnnaSutherlandModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, AnnaSutherlandModMod.MODID);
	public static final RegistryObject<Block> THEIMPOSSIBLE = REGISTRY.register("theimpossible", () -> new TheimpossibleBlock());
	public static final RegistryObject<Block> RED = REGISTRY.register("red", () -> new RedBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
