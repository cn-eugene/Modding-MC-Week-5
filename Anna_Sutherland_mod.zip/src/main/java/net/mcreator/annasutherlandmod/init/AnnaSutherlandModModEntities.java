
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.annasutherlandmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.annasutherlandmod.entity.SarewqEntity;
import net.mcreator.annasutherlandmod.entity.QpEntity;
import net.mcreator.annasutherlandmod.entity.GtrEntity;
import net.mcreator.annasutherlandmod.entity.BEntity;
import net.mcreator.annasutherlandmod.AnnaSutherlandModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AnnaSutherlandModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AnnaSutherlandModMod.MODID);
	public static final RegistryObject<EntityType<BEntity>> B = register("b",
			EntityType.Builder.<BEntity>of(BEntity::new, MobCategory.MISC).setCustomClientFactory(BEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<QpEntity>> QP = register("qp",
			EntityType.Builder.<QpEntity>of(QpEntity::new, MobCategory.MISC).setCustomClientFactory(QpEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<GtrEntity>> GTR = register("gtr",
			EntityType.Builder.<GtrEntity>of(GtrEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(66).setUpdateInterval(3).setCustomClientFactory(GtrEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<SarewqEntity>> SAREWQ = register("sarewq",
			EntityType.Builder.<SarewqEntity>of(SarewqEntity::new, MobCategory.WATER_CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(77).setUpdateInterval(3).setCustomClientFactory(SarewqEntity::new)

					.sized(0.6f, 2.7f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			GtrEntity.init();
			SarewqEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(GTR.get(), GtrEntity.createAttributes().build());
		event.put(SAREWQ.get(), SarewqEntity.createAttributes().build());
	}
}
