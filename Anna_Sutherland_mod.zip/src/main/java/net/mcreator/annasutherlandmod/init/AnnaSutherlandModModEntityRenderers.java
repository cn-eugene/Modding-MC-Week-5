
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.annasutherlandmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.annasutherlandmod.client.renderer.SarewqRenderer;
import net.mcreator.annasutherlandmod.client.renderer.GtrRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class AnnaSutherlandModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(AnnaSutherlandModModEntities.B.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(AnnaSutherlandModModEntities.QP.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(AnnaSutherlandModModEntities.GTR.get(), GtrRenderer::new);
		event.registerEntityRenderer(AnnaSutherlandModModEntities.SAREWQ.get(), SarewqRenderer::new);
	}
}
