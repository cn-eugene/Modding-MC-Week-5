
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.annasutherlandmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.annasutherlandmod.AnnaSutherlandModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AnnaSutherlandModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AnnaSutherlandModMod.MODID);
	public static final RegistryObject<CreativeModeTab> ANNAS = REGISTRY.register("annas",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.anna_sutherland_mod.annas")).icon(() -> new ItemStack(AnnaSutherlandModModItems.EW.get())).displayItems((parameters, tabData) -> {
				tabData.accept(AnnaSutherlandModModBlocks.THEIMPOSSIBLE.get().asItem());
				tabData.accept(AnnaSutherlandModModItems.EW.get());
				tabData.accept(AnnaSutherlandModModItems.WERTY.get());
				tabData.accept(AnnaSutherlandModModItems.MADMOD.get());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(AnnaSutherlandModModItems.MASTERSWORD.get());
			tabData.accept(AnnaSutherlandModModItems.MARIN_HELMET.get());
			tabData.accept(AnnaSutherlandModModItems.MARIN_CHESTPLATE.get());
			tabData.accept(AnnaSutherlandModModItems.MARIN_LEGGINGS.get());
			tabData.accept(AnnaSutherlandModModItems.MARIN_BOOTS.get());
			tabData.accept(AnnaSutherlandModModItems.SPEAR.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AnnaSutherlandModModItems.GTR_SPAWN_EGG.get());
			tabData.accept(AnnaSutherlandModModItems.SAREWQ_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(AnnaSutherlandModModItems.COLERMAN.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(AnnaSutherlandModModBlocks.RED.get().asItem());
		}
	}
}
