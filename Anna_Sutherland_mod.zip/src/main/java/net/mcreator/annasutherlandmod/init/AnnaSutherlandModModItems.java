
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.annasutherlandmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.annasutherlandmod.item.WertyItem;
import net.mcreator.annasutherlandmod.item.SpearItem;
import net.mcreator.annasutherlandmod.item.MasterswordItem;
import net.mcreator.annasutherlandmod.item.MadmodItem;
import net.mcreator.annasutherlandmod.item.MARINItem;
import net.mcreator.annasutherlandmod.item.EwItem;
import net.mcreator.annasutherlandmod.item.COLERMANItem;
import net.mcreator.annasutherlandmod.AnnaSutherlandModMod;

public class AnnaSutherlandModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AnnaSutherlandModMod.MODID);
	public static final RegistryObject<Item> THEIMPOSSIBLE = block(AnnaSutherlandModModBlocks.THEIMPOSSIBLE);
	public static final RegistryObject<Item> RED = block(AnnaSutherlandModModBlocks.RED);
	public static final RegistryObject<Item> COLERMAN = REGISTRY.register("colerman", () -> new COLERMANItem());
	public static final RegistryObject<Item> MASTERSWORD = REGISTRY.register("mastersword", () -> new MasterswordItem());
	public static final RegistryObject<Item> MARIN_HELMET = REGISTRY.register("marin_helmet", () -> new MARINItem.Helmet());
	public static final RegistryObject<Item> MARIN_CHESTPLATE = REGISTRY.register("marin_chestplate", () -> new MARINItem.Chestplate());
	public static final RegistryObject<Item> MARIN_LEGGINGS = REGISTRY.register("marin_leggings", () -> new MARINItem.Leggings());
	public static final RegistryObject<Item> MARIN_BOOTS = REGISTRY.register("marin_boots", () -> new MARINItem.Boots());
	public static final RegistryObject<Item> SPEAR = REGISTRY.register("spear", () -> new SpearItem());
	public static final RegistryObject<Item> EW = REGISTRY.register("ew", () -> new EwItem());
	public static final RegistryObject<Item> GTR_SPAWN_EGG = REGISTRY.register("gtr_spawn_egg", () -> new ForgeSpawnEggItem(AnnaSutherlandModModEntities.GTR, -16711681, -256, new Item.Properties()));
	public static final RegistryObject<Item> WERTY = REGISTRY.register("werty", () -> new WertyItem());
	public static final RegistryObject<Item> MADMOD = REGISTRY.register("madmod", () -> new MadmodItem());
	public static final RegistryObject<Item> SAREWQ_SPAWN_EGG = REGISTRY.register("sarewq_spawn_egg", () -> new ForgeSpawnEggItem(AnnaSutherlandModModEntities.SAREWQ, -205, -65281, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
