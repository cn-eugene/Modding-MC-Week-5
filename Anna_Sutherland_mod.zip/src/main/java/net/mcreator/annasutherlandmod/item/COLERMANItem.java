
package net.mcreator.annasutherlandmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class COLERMANItem extends Item {
	public COLERMANItem() {
		super(new Item.Properties().stacksTo(50).fireResistant().rarity(Rarity.COMMON));
	}

	@Override
	public int getEnchantmentValue() {
		return 11;
	}
}
