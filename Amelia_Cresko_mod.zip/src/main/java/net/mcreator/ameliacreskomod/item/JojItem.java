
package net.mcreator.ameliacreskomod.item;

import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.Item;

public class JojItem extends ShieldItem {
	public JojItem() {
		super(new Item.Properties().durability(158));
	}
}
