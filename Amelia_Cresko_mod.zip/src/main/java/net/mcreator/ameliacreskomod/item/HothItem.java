
package net.mcreator.ameliacreskomod.item;

import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.Item;

public class HothItem extends ShieldItem {
	public HothItem() {
		super(new Item.Properties().durability(100));
	}
}
