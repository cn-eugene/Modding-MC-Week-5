
package net.mcreator.ameliacreskomod.item;

import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.Item;

public class GorgItem extends ShieldItem {
	public GorgItem() {
		super(new Item.Properties().durability(355));
	}
}
