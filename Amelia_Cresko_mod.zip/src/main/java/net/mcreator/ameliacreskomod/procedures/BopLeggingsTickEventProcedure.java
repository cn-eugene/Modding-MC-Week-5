package net.mcreator.ameliacreskomod.procedures;

public class BopLeggingsTickEventProcedure {
	public static void execute() {
	}
}
