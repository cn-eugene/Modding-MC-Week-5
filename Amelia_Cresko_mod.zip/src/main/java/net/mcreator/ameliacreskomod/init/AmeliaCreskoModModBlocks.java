
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ameliacreskomod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.ameliacreskomod.block.YyuBlock;
import net.mcreator.ameliacreskomod.block.VovBlock;
import net.mcreator.ameliacreskomod.block.TotBlock;
import net.mcreator.ameliacreskomod.block.PopBlock;
import net.mcreator.ameliacreskomod.block.HyrsBlock;
import net.mcreator.ameliacreskomod.block.HOHBlock;
import net.mcreator.ameliacreskomod.block.FirBlock;
import net.mcreator.ameliacreskomod.AmeliaCreskoModMod;

public class AmeliaCreskoModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, AmeliaCreskoModMod.MODID);
	public static final RegistryObject<Block> FIR = REGISTRY.register("fir", () -> new FirBlock());
	public static final RegistryObject<Block> YYU = REGISTRY.register("yyu", () -> new YyuBlock());
	public static final RegistryObject<Block> HYRS = REGISTRY.register("hyrs", () -> new HyrsBlock());
	public static final RegistryObject<Block> VOV = REGISTRY.register("vov", () -> new VovBlock());
	public static final RegistryObject<Block> POP = REGISTRY.register("pop", () -> new PopBlock());
	public static final RegistryObject<Block> TOT = REGISTRY.register("tot", () -> new TotBlock());
	public static final RegistryObject<Block> HOH = REGISTRY.register("hoh", () -> new HOHBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
