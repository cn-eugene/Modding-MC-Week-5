
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ameliacreskomod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.ameliacreskomod.entity.RertEntity;
import net.mcreator.ameliacreskomod.entity.PoipEntity;
import net.mcreator.ameliacreskomod.entity.KOEntity;
import net.mcreator.ameliacreskomod.entity.IliEntity;
import net.mcreator.ameliacreskomod.entity.GuyEntity;
import net.mcreator.ameliacreskomod.entity.FUFEntity;
import net.mcreator.ameliacreskomod.AmeliaCreskoModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AmeliaCreskoModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AmeliaCreskoModMod.MODID);
	public static final RegistryObject<EntityType<FUFEntity>> FUF = register("fuf",
			EntityType.Builder.<FUFEntity>of(FUFEntity::new, MobCategory.MISC).setCustomClientFactory(FUFEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<GuyEntity>> GUY = register("guy",
			EntityType.Builder.<GuyEntity>of(GuyEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(GuyEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<PoipEntity>> POIP = register("poip",
			EntityType.Builder.<PoipEntity>of(PoipEntity::new, MobCategory.MISC).setCustomClientFactory(PoipEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<RertEntity>> RERT = register("rert",
			EntityType.Builder.<RertEntity>of(RertEntity::new, MobCategory.MISC).setCustomClientFactory(RertEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<KOEntity>> KO = register("ko",
			EntityType.Builder.<KOEntity>of(KOEntity::new, MobCategory.MISC).setCustomClientFactory(KOEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<IliEntity>> ILI = register("ili",
			EntityType.Builder.<IliEntity>of(IliEntity::new, MobCategory.MISC).setCustomClientFactory(IliEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			GuyEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(GUY.get(), GuyEntity.createAttributes().build());
	}
}
