
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ameliacreskomod.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.ameliacreskomod.AmeliaCreskoModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AmeliaCreskoModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AmeliaCreskoModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(AmeliaCreskoModModBlocks.HYRS.get().asItem());
			tabData.accept(AmeliaCreskoModModBlocks.TOT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(AmeliaCreskoModModItems.ERT.get());
			tabData.accept(AmeliaCreskoModModItems.GOG.get());
			tabData.accept(AmeliaCreskoModModItems.JOJ.get());
			tabData.accept(AmeliaCreskoModModItems.HUH.get());
			tabData.accept(AmeliaCreskoModModItems.BOP_HELMET.get());
			tabData.accept(AmeliaCreskoModModItems.BOP_CHESTPLATE.get());
			tabData.accept(AmeliaCreskoModModItems.BOP_LEGGINGS.get());
			tabData.accept(AmeliaCreskoModModItems.BOP_BOOTS.get());
			tabData.accept(AmeliaCreskoModModItems.HUP.get());
			tabData.accept(AmeliaCreskoModModItems.LOL.get());
			tabData.accept(AmeliaCreskoModModItems.IOI.get());
			tabData.accept(AmeliaCreskoModModItems.GUG.get());
			tabData.accept(AmeliaCreskoModModItems.HOI.get());
			tabData.accept(AmeliaCreskoModModItems.OJOJ_HELMET.get());
			tabData.accept(AmeliaCreskoModModItems.OJOJ_CHESTPLATE.get());
			tabData.accept(AmeliaCreskoModModItems.OJOJ_LEGGINGS.get());
			tabData.accept(AmeliaCreskoModModItems.OJOJ_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AmeliaCreskoModModItems.HOTH.get());
			tabData.accept(AmeliaCreskoModModItems.GUY_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(AmeliaCreskoModModItems.NEON.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(AmeliaCreskoModModItems.GORG.get());
			tabData.accept(AmeliaCreskoModModItems.KOK.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(AmeliaCreskoModModBlocks.VOV.get().asItem());
			tabData.accept(AmeliaCreskoModModBlocks.POP.get().asItem());
		}
	}
}
