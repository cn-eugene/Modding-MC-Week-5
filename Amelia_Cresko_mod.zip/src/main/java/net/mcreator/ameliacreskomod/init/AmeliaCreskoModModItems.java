
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ameliacreskomod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.ameliacreskomod.item.OjojItem;
import net.mcreator.ameliacreskomod.item.NeonItem;
import net.mcreator.ameliacreskomod.item.LolItem;
import net.mcreator.ameliacreskomod.item.KokItem;
import net.mcreator.ameliacreskomod.item.JojItem;
import net.mcreator.ameliacreskomod.item.IoiItem;
import net.mcreator.ameliacreskomod.item.HupItem;
import net.mcreator.ameliacreskomod.item.HuhItem;
import net.mcreator.ameliacreskomod.item.HothItem;
import net.mcreator.ameliacreskomod.item.HOIItem;
import net.mcreator.ameliacreskomod.item.GorgItem;
import net.mcreator.ameliacreskomod.item.GogItem;
import net.mcreator.ameliacreskomod.item.GUGItem;
import net.mcreator.ameliacreskomod.item.ErtItem;
import net.mcreator.ameliacreskomod.item.BopItem;
import net.mcreator.ameliacreskomod.AmeliaCreskoModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class AmeliaCreskoModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AmeliaCreskoModMod.MODID);
	public static final RegistryObject<Item> FIR = block(AmeliaCreskoModModBlocks.FIR);
	public static final RegistryObject<Item> YYU = block(AmeliaCreskoModModBlocks.YYU);
	public static final RegistryObject<Item> HYRS = block(AmeliaCreskoModModBlocks.HYRS);
	public static final RegistryObject<Item> NEON = REGISTRY.register("neon", () -> new NeonItem());
	public static final RegistryObject<Item> ERT = REGISTRY.register("ert", () -> new ErtItem());
	public static final RegistryObject<Item> GOG = REGISTRY.register("gog", () -> new GogItem());
	public static final RegistryObject<Item> HOTH = REGISTRY.register("hoth", () -> new HothItem());
	public static final RegistryObject<Item> JOJ = REGISTRY.register("joj", () -> new JojItem());
	public static final RegistryObject<Item> HUH = REGISTRY.register("huh", () -> new HuhItem());
	public static final RegistryObject<Item> BOP_HELMET = REGISTRY.register("bop_helmet", () -> new BopItem.Helmet());
	public static final RegistryObject<Item> BOP_CHESTPLATE = REGISTRY.register("bop_chestplate", () -> new BopItem.Chestplate());
	public static final RegistryObject<Item> BOP_LEGGINGS = REGISTRY.register("bop_leggings", () -> new BopItem.Leggings());
	public static final RegistryObject<Item> BOP_BOOTS = REGISTRY.register("bop_boots", () -> new BopItem.Boots());
	public static final RegistryObject<Item> HUP = REGISTRY.register("hup", () -> new HupItem());
	public static final RegistryObject<Item> GORG = REGISTRY.register("gorg", () -> new GorgItem());
	public static final RegistryObject<Item> VOV = block(AmeliaCreskoModModBlocks.VOV);
	public static final RegistryObject<Item> POP = block(AmeliaCreskoModModBlocks.POP);
	public static final RegistryObject<Item> TOT = block(AmeliaCreskoModModBlocks.TOT);
	public static final RegistryObject<Item> LOL = REGISTRY.register("lol", () -> new LolItem());
	public static final RegistryObject<Item> KOK = REGISTRY.register("kok", () -> new KokItem());
	public static final RegistryObject<Item> IOI = REGISTRY.register("ioi", () -> new IoiItem());
	public static final RegistryObject<Item> GUG = REGISTRY.register("gug", () -> new GUGItem());
	public static final RegistryObject<Item> GUY_SPAWN_EGG = REGISTRY.register("guy_spawn_egg", () -> new ForgeSpawnEggItem(AmeliaCreskoModModEntities.GUY, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> HOH = block(AmeliaCreskoModModBlocks.HOH);
	public static final RegistryObject<Item> HOI = REGISTRY.register("hoi", () -> new HOIItem());
	public static final RegistryObject<Item> OJOJ_HELMET = REGISTRY.register("ojoj_helmet", () -> new OjojItem.Helmet());
	public static final RegistryObject<Item> OJOJ_CHESTPLATE = REGISTRY.register("ojoj_chestplate", () -> new OjojItem.Chestplate());
	public static final RegistryObject<Item> OJOJ_LEGGINGS = REGISTRY.register("ojoj_leggings", () -> new OjojItem.Leggings());
	public static final RegistryObject<Item> OJOJ_BOOTS = REGISTRY.register("ojoj_boots", () -> new OjojItem.Boots());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			ItemProperties.register(HOTH.get(), new ResourceLocation("blocking"), ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
			ItemProperties.register(JOJ.get(), new ResourceLocation("blocking"), ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
			ItemProperties.register(HUH.get(), new ResourceLocation("blocking"), ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
			ItemProperties.register(GORG.get(), new ResourceLocation("blocking"), ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
		});
	}
}
