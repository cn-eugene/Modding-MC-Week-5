
package net.mcreator.oscarlavelle.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.oscarlavelle.entity.YyyyyyEntity;

public class YyyyyyRenderer extends HumanoidMobRenderer<YyyyyyEntity, HumanoidModel<YyyyyyEntity>> {
	public YyyyyyRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(YyyyyyEntity entity) {
		return new ResourceLocation("oscar_lavelle:textures/entities/0349d01412bb80a931f95d59ab3adfe3c09a4dd4.png");
	}
}
