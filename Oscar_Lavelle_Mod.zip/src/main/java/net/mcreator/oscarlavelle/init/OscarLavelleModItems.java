
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oscarlavelle.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.oscarlavelle.item.SkeldItem;
import net.mcreator.oscarlavelle.item.ShurikinItem;
import net.mcreator.oscarlavelle.item.PlatfireswordItem;
import net.mcreator.oscarlavelle.item.PlasmekatanaItem;
import net.mcreator.oscarlavelle.item.Pick99Item;
import net.mcreator.oscarlavelle.item.KunaiItem;
import net.mcreator.oscarlavelle.item.FlightarmorItem;
import net.mcreator.oscarlavelle.item.FireItem;
import net.mcreator.oscarlavelle.OscarLavelleMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class OscarLavelleModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, OscarLavelleMod.MODID);
	public static final RegistryObject<Item> MORPHEDGRASS = block(OscarLavelleModBlocks.MORPHEDGRASS);
	public static final RegistryObject<Item> SAPHIREORE = block(OscarLavelleModBlocks.SAPHIREORE);
	public static final RegistryObject<Item> FIRE = REGISTRY.register("fire", () -> new FireItem());
	public static final RegistryObject<Item> PLATFIRESWORD = REGISTRY.register("platfiresword", () -> new PlatfireswordItem());
	public static final RegistryObject<Item> SKELD = REGISTRY.register("skeld", () -> new SkeldItem());
	public static final RegistryObject<Item> FLIGHTARMOR_HELMET = REGISTRY.register("flightarmor_helmet", () -> new FlightarmorItem.Helmet());
	public static final RegistryObject<Item> FLIGHTARMOR_CHESTPLATE = REGISTRY.register("flightarmor_chestplate", () -> new FlightarmorItem.Chestplate());
	public static final RegistryObject<Item> FLIGHTARMOR_LEGGINGS = REGISTRY.register("flightarmor_leggings", () -> new FlightarmorItem.Leggings());
	public static final RegistryObject<Item> FLIGHTARMOR_BOOTS = REGISTRY.register("flightarmor_boots", () -> new FlightarmorItem.Boots());
	public static final RegistryObject<Item> SHURIKIN = REGISTRY.register("shurikin", () -> new ShurikinItem());
	public static final RegistryObject<Item> YYYYYY_SPAWN_EGG = REGISTRY.register("yyyyyy_spawn_egg", () -> new ForgeSpawnEggItem(OscarLavelleModEntities.YYYYYY, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> KUNAI = REGISTRY.register("kunai", () -> new KunaiItem());
	public static final RegistryObject<Item> PLASMEKATANA = REGISTRY.register("plasmekatana", () -> new PlasmekatanaItem());
	public static final RegistryObject<Item> PICK_99 = REGISTRY.register("pick_99", () -> new Pick99Item());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			ItemProperties.register(SKELD.get(), new ResourceLocation("blocking"), ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
		});
	}
}
