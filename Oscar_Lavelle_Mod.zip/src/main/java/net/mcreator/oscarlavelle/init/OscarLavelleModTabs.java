
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oscarlavelle.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.oscarlavelle.OscarLavelleMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OscarLavelleModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, OscarLavelleMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(OscarLavelleModItems.PLATFIRESWORD.get());
			tabData.accept(OscarLavelleModItems.SKELD.get());
			tabData.accept(OscarLavelleModItems.FLIGHTARMOR_HELMET.get());
			tabData.accept(OscarLavelleModItems.FLIGHTARMOR_CHESTPLATE.get());
			tabData.accept(OscarLavelleModItems.FLIGHTARMOR_LEGGINGS.get());
			tabData.accept(OscarLavelleModItems.FLIGHTARMOR_BOOTS.get());
			tabData.accept(OscarLavelleModItems.SHURIKIN.get());
			tabData.accept(OscarLavelleModItems.KUNAI.get());
			tabData.accept(OscarLavelleModItems.PLASMEKATANA.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(OscarLavelleModItems.YYYYYY_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(OscarLavelleModItems.FIRE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(OscarLavelleModBlocks.SAPHIREORE.get().asItem());
			tabData.accept(OscarLavelleModBlocks.MORPHEDGRASS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(OscarLavelleModItems.PICK_99.get());
		}
	}
}
