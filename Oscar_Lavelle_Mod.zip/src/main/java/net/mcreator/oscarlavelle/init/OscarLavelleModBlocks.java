
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oscarlavelle.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.oscarlavelle.block.SaphireoreBlock;
import net.mcreator.oscarlavelle.block.MorphedgrassBlock;
import net.mcreator.oscarlavelle.OscarLavelleMod;

public class OscarLavelleModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, OscarLavelleMod.MODID);
	public static final RegistryObject<Block> MORPHEDGRASS = REGISTRY.register("morphedgrass", () -> new MorphedgrassBlock());
	public static final RegistryObject<Block> SAPHIREORE = REGISTRY.register("saphireore", () -> new SaphireoreBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
