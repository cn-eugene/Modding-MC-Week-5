
package net.mcreator.oscarlavelle.item;

import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.Item;

public class SkeldItem extends ShieldItem {
	public SkeldItem() {
		super(new Item.Properties().durability(2000).fireResistant());
	}
}
