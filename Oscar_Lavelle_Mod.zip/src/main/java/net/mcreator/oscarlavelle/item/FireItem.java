
package net.mcreator.oscarlavelle.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class FireItem extends Item {
	public FireItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON));
	}
}
