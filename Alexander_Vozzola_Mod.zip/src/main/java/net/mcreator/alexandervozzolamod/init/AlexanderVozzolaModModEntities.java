
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alexandervozzolamod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.alexandervozzolamod.entity.YourdeadEntity;
import net.mcreator.alexandervozzolamod.entity.WardenskidEntity;
import net.mcreator.alexandervozzolamod.entity.TbtbEntity;
import net.mcreator.alexandervozzolamod.entity.DeathballEntity;
import net.mcreator.alexandervozzolamod.AlexanderVozzolaModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AlexanderVozzolaModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AlexanderVozzolaModMod.MODID);
	public static final RegistryObject<EntityType<TbtbEntity>> TBTB = register("tbtb",
			EntityType.Builder.<TbtbEntity>of(TbtbEntity::new, MobCategory.MISC).setCustomClientFactory(TbtbEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<DeathballEntity>> DEATHBALL = register("deathball",
			EntityType.Builder.<DeathballEntity>of(DeathballEntity::new, MobCategory.MISC).setCustomClientFactory(DeathballEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<YourdeadEntity>> YOURDEAD = register("yourdead",
			EntityType.Builder.<YourdeadEntity>of(YourdeadEntity::new, MobCategory.MISC).setCustomClientFactory(YourdeadEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<WardenskidEntity>> WARDENSKID = register("wardenskid", EntityType.Builder.<WardenskidEntity>of(WardenskidEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(WardenskidEntity::new).fireImmune().sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			WardenskidEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(WARDENSKID.get(), WardenskidEntity.createAttributes().build());
	}
}
