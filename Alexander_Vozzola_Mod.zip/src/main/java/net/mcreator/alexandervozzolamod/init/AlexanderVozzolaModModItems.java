
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alexandervozzolamod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.alexandervozzolamod.item.RipItem;
import net.mcreator.alexandervozzolamod.item.EEGGGGGGItem;
import net.mcreator.alexandervozzolamod.item.DeathdiamoundItem;
import net.mcreator.alexandervozzolamod.item.DeathchargeItem;
import net.mcreator.alexandervozzolamod.item.DeadlyItem;
import net.mcreator.alexandervozzolamod.item.CrossswordItem;
import net.mcreator.alexandervozzolamod.AlexanderVozzolaModMod;

public class AlexanderVozzolaModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AlexanderVozzolaModMod.MODID);
	public static final RegistryObject<Item> DEATH = block(AlexanderVozzolaModModBlocks.DEATH);
	public static final RegistryObject<Item> DEATHDIAMOUND = REGISTRY.register("deathdiamound", () -> new DeathdiamoundItem());
	public static final RegistryObject<Item> DEATHORE = block(AlexanderVozzolaModModBlocks.DEATHORE);
	public static final RegistryObject<Item> DEADLY = REGISTRY.register("deadly", () -> new DeadlyItem());
	public static final RegistryObject<Item> RIP = REGISTRY.register("rip", () -> new RipItem());
	public static final RegistryObject<Item> EEGGGGGG_HELMET = REGISTRY.register("eegggggg_helmet", () -> new EEGGGGGGItem.Helmet());
	public static final RegistryObject<Item> EEGGGGGG_CHESTPLATE = REGISTRY.register("eegggggg_chestplate", () -> new EEGGGGGGItem.Chestplate());
	public static final RegistryObject<Item> EEGGGGGG_LEGGINGS = REGISTRY.register("eegggggg_leggings", () -> new EEGGGGGGItem.Leggings());
	public static final RegistryObject<Item> EEGGGGGG_BOOTS = REGISTRY.register("eegggggg_boots", () -> new EEGGGGGGItem.Boots());
	public static final RegistryObject<Item> DEATHCHARGE = REGISTRY.register("deathcharge", () -> new DeathchargeItem());
	public static final RegistryObject<Item> CROSSSWORD = REGISTRY.register("crosssword", () -> new CrossswordItem());
	public static final RegistryObject<Item> WARDENSKID_SPAWN_EGG = REGISTRY.register("wardenskid_spawn_egg", () -> new ForgeSpawnEggItem(AlexanderVozzolaModModEntities.WARDENSKID, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
