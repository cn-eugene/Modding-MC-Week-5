
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alexandervozzolamod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.alexandervozzolamod.client.renderer.WardenskidRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class AlexanderVozzolaModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(AlexanderVozzolaModModEntities.TBTB.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(AlexanderVozzolaModModEntities.DEATHBALL.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(AlexanderVozzolaModModEntities.YOURDEAD.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(AlexanderVozzolaModModEntities.WARDENSKID.get(), WardenskidRenderer::new);
	}
}
