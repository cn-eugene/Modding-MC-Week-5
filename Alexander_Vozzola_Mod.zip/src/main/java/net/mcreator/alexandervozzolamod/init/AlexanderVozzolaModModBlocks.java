
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alexandervozzolamod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.alexandervozzolamod.block.DeathoreBlock;
import net.mcreator.alexandervozzolamod.block.DeadlyPortalBlock;
import net.mcreator.alexandervozzolamod.block.DEATHBlock;
import net.mcreator.alexandervozzolamod.AlexanderVozzolaModMod;

public class AlexanderVozzolaModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, AlexanderVozzolaModMod.MODID);
	public static final RegistryObject<Block> DEATH = REGISTRY.register("death", () -> new DEATHBlock());
	public static final RegistryObject<Block> DEATHORE = REGISTRY.register("deathore", () -> new DeathoreBlock());
	public static final RegistryObject<Block> DEADLY_PORTAL = REGISTRY.register("deadly_portal", () -> new DeadlyPortalBlock());

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			DeathoreBlock.blockColorLoad(event);
		}
	}
}
