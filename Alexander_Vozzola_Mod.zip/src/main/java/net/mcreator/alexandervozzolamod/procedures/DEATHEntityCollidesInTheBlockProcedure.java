package net.mcreator.alexandervozzolamod.procedures;

import net.minecraft.world.entity.Entity;

public class DEATHEntityCollidesInTheBlockProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setSecondsOnFire(60);
	}
}
