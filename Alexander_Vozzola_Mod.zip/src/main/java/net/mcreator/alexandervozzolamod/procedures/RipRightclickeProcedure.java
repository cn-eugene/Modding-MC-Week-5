package net.mcreator.alexandervozzolamod.procedures;

public class RipRightclickeProcedure {
	public static void execute() {
	}
}
