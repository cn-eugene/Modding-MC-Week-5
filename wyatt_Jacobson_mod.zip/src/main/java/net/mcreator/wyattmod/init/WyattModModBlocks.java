
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wyattmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.wyattmod.block.Ktgfguj6b7yuBlock;
import net.mcreator.wyattmod.block.Htugtjuygtutgyhyyu0Block;
import net.mcreator.wyattmod.WyattModMod;

public class WyattModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, WyattModMod.MODID);
	public static final RegistryObject<Block> KTGFGUJ_6B_7YU = REGISTRY.register("ktgfguj_6b_7yu", () -> new Ktgfguj6b7yuBlock());
	public static final RegistryObject<Block> HTUGTJUYGTUTGYHYYU_0 = REGISTRY.register("htugtjuygtutgyhyyu_0", () -> new Htugtjuygtutgyhyyu0Block());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
