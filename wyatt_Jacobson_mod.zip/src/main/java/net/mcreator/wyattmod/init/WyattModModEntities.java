
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wyattmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.wyattmod.entity.NfhtikutithtrujEntity;
import net.mcreator.wyattmod.entity.Hfghthyhry4rhgnth4yrthrgthyghhtyghhEntity;
import net.mcreator.wyattmod.WyattModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class WyattModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, WyattModMod.MODID);
	public static final RegistryObject<EntityType<NfhtikutithtrujEntity>> NFHTIKUTITHTRUJ = register("nfhtikutithtruj", EntityType.Builder.<NfhtikutithtrujEntity>of(NfhtikutithtrujEntity::new, MobCategory.MISC)
			.setCustomClientFactory(NfhtikutithtrujEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<Hfghthyhry4rhgnth4yrthrgthyghhtyghhEntity>> HFGHTHYHRY_4RHGNTH_4YRTHRGTHYGHHTYGHH = register("hfghthyhry_4rhgnth_4yrthrgthyghhtyghh",
			EntityType.Builder.<Hfghthyhry4rhgnth4yrthrgthyghhtyghhEntity>of(Hfghthyhry4rhgnth4yrthrgthyghhtyghhEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(518).setUpdateInterval(3)
					.setCustomClientFactory(Hfghthyhry4rhgnth4yrthrgthyghhtyghhEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			Hfghthyhry4rhgnth4yrthrgthyghhtyghhEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(HFGHTHYHRY_4RHGNTH_4YRTHRGTHYGHHTYGHH.get(), Hfghthyhry4rhgnth4yrthrgthyghhtyghhEntity.createAttributes().build());
	}
}
