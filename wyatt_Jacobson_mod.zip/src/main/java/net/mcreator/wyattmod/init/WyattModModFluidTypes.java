
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wyattmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.wyattmod.fluid.types.Htugtjuygtutgyhyyu0FluidType;
import net.mcreator.wyattmod.WyattModMod;

public class WyattModModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, WyattModMod.MODID);
	public static final RegistryObject<FluidType> HTUGTJUYGTUTGYHYYU_0_TYPE = REGISTRY.register("htugtjuygtutgyhyyu_0", () -> new Htugtjuygtutgyhyyu0FluidType());
}
