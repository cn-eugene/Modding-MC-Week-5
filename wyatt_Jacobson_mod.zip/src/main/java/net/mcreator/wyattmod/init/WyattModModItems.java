
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wyattmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.wyattmod.item.VgbhththhfghtgbhnbgmnhtnItem;
import net.mcreator.wyattmod.item.IngotItem;
import net.mcreator.wyattmod.item.Htugtjuygtutgyhyyu0Item;
import net.mcreator.wyattmod.item.Hjvfh3dgdhjrejhgfhghjrjuItem;
import net.mcreator.wyattmod.item.HTSHFGIJGVGHBTGY5U557665UT65UItem;
import net.mcreator.wyattmod.WyattModMod;

public class WyattModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, WyattModMod.MODID);
	public static final RegistryObject<Item> INGOT = REGISTRY.register("ingot", () -> new IngotItem());
	public static final RegistryObject<Item> HTSHFGIJGVGHBTGY_5_U_557665_UT_65_U = REGISTRY.register("htshfgijgvghbtgy_5_u_557665_ut_65_u", () -> new HTSHFGIJGVGHBTGY5U557665UT65UItem());
	public static final RegistryObject<Item> HJVFH_3DGDHJREJHGFHGHJRJU = REGISTRY.register("hjvfh_3dgdhjrejhgfhghjrju", () -> new Hjvfh3dgdhjrejhgfhghjrjuItem());
	public static final RegistryObject<Item> VGBHTHTHHFGHTGBHNBGMNHTN = REGISTRY.register("vgbhththhfghtgbhnbgmnhtn", () -> new VgbhththhfghtgbhnbgmnhtnItem());
	public static final RegistryObject<Item> KTGFGUJ_6B_7YU = block(WyattModModBlocks.KTGFGUJ_6B_7YU);
	public static final RegistryObject<Item> HTUGTJUYGTUTGYHYYU_0_BUCKET = REGISTRY.register("htugtjuygtutgyhyyu_0_bucket", () -> new Htugtjuygtutgyhyyu0Item());
	public static final RegistryObject<Item> HFGHTHYHRY_4RHGNTH_4YRTHRGTHYGHHTYGHH_SPAWN_EGG = REGISTRY.register("hfghthyhry_4rhgnth_4yrthrgthyghhtyghh_spawn_egg",
			() -> new ForgeSpawnEggItem(WyattModModEntities.HFGHTHYHRY_4RHGNTH_4YRTHRGTHYGHHTYGHH, -10027162, -13369549, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
