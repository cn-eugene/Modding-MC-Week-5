
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wyattmod.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.wyattmod.WyattModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class WyattModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, WyattModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(WyattModModItems.INGOT.get());
			tabData.accept(WyattModModBlocks.KTGFGUJ_6B_7YU.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(WyattModModItems.HFGHTHYHRY_4RHGNTH_4YRTHRGTHYGHHTYGHH_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(WyattModModItems.HTSHFGIJGVGHBTGY_5_U_557665_UT_65_U.get());
			tabData.accept(WyattModModItems.HJVFH_3DGDHJREJHGFHGHJRJU.get());
		}
	}
}
