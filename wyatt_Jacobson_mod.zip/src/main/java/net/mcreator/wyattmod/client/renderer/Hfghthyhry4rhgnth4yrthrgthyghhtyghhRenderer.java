
package net.mcreator.wyattmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.wyattmod.entity.Hfghthyhry4rhgnth4yrthrgthyghhtyghhEntity;

public class Hfghthyhry4rhgnth4yrthrgthyghhtyghhRenderer extends HumanoidMobRenderer<Hfghthyhry4rhgnth4yrthrgthyghhtyghhEntity, HumanoidModel<Hfghthyhry4rhgnth4yrthrgthyghhtyghhEntity>> {
	public Hfghthyhry4rhgnth4yrthrgthyghhtyghhRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(Hfghthyhry4rhgnth4yrthrgthyghhtyghhEntity entity) {
		return new ResourceLocation("wyatt_mod:textures/entities/34115758cd602a45aff09c58ab7565fd4707c6de.png");
	}
}
