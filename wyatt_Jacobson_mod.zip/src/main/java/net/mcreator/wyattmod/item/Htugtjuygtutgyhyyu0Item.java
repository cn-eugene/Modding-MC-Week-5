
package net.mcreator.wyattmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.wyattmod.init.WyattModModFluids;

public class Htugtjuygtutgyhyyu0Item extends BucketItem {
	public Htugtjuygtutgyhyyu0Item() {
		super(WyattModModFluids.HTUGTJUYGTUTGYHYYU_0, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON));
	}
}
