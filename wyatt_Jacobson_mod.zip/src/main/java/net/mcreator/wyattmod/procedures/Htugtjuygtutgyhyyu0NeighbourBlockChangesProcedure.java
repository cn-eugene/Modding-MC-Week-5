package net.mcreator.wyattmod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.wyattmod.init.WyattModModBlocks;

public class Htugtjuygtutgyhyyu0NeighbourBlockChangesProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world.getBlockState(BlockPos.containing(x + 1, y, z)).canOcclude()) {
			world.setBlock(BlockPos.containing(x + 1, y, z), WyattModModBlocks.KTGFGUJ_6B_7YU.get().defaultBlockState(), 3);
		}
		if (world.getBlockState(BlockPos.containing(x + -1, y, z)).canOcclude()) {
			world.setBlock(BlockPos.containing(x + -1, y, z), WyattModModBlocks.KTGFGUJ_6B_7YU.get().defaultBlockState(), 3);
		}
		if (world.getBlockState(BlockPos.containing(x, y + 1, z)).canOcclude()) {
			world.setBlock(BlockPos.containing(x, y + 1, z), WyattModModBlocks.KTGFGUJ_6B_7YU.get().defaultBlockState(), 3);
		}
		if (world.getBlockState(BlockPos.containing(x, y + -1, z)).canOcclude()) {
			world.setBlock(BlockPos.containing(x, y + -1, z), WyattModModBlocks.KTGFGUJ_6B_7YU.get().defaultBlockState(), 3);
		}
		if (world.getBlockState(BlockPos.containing(x, y, z + 1)).canOcclude()) {
			world.setBlock(BlockPos.containing(x, y, z + 1), WyattModModBlocks.KTGFGUJ_6B_7YU.get().defaultBlockState(), 3);
		}
		if (world.getBlockState(BlockPos.containing(x, y, z + -1)).canOcclude()) {
			world.setBlock(BlockPos.containing(x, y, z + -1), WyattModModBlocks.KTGFGUJ_6B_7YU.get().defaultBlockState(), 3);
		}
	}
}
