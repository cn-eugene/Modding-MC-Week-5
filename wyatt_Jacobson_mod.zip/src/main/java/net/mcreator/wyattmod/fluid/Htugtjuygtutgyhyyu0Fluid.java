
package net.mcreator.wyattmod.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.wyattmod.init.WyattModModItems;
import net.mcreator.wyattmod.init.WyattModModFluids;
import net.mcreator.wyattmod.init.WyattModModFluidTypes;
import net.mcreator.wyattmod.init.WyattModModBlocks;

public abstract class Htugtjuygtutgyhyyu0Fluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> WyattModModFluidTypes.HTUGTJUYGTUTGYHYYU_0_TYPE.get(), () -> WyattModModFluids.HTUGTJUYGTUTGYHYYU_0.get(),
			() -> WyattModModFluids.FLOWING_HTUGTJUYGTUTGYHYYU_0.get()).explosionResistance(100f).tickRate(45).slopeFindDistance(16).bucket(() -> WyattModModItems.HTUGTJUYGTUTGYHYYU_0_BUCKET.get())
			.block(() -> (LiquidBlock) WyattModModBlocks.HTUGTJUYGTUTGYHYYU_0.get());

	private Htugtjuygtutgyhyyu0Fluid() {
		super(PROPERTIES);
	}

	public static class Source extends Htugtjuygtutgyhyyu0Fluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends Htugtjuygtutgyhyyu0Fluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
