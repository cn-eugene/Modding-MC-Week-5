package net.mcreator.calvinhagermanmod.procedures;

import net.minecraft.world.entity.Entity;

public class ExtremearrowaxeLivingEntityIsHitWithToolProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setSecondsOnFire(60);
	}
}
