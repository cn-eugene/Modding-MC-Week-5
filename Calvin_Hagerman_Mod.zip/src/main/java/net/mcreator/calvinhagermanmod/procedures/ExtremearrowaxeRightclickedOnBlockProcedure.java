package net.mcreator.calvinhagermanmod.procedures;

import net.minecraft.world.entity.Entity;

public class ExtremearrowaxeRightclickedOnBlockProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setSecondsOnFire(30);
	}
}
