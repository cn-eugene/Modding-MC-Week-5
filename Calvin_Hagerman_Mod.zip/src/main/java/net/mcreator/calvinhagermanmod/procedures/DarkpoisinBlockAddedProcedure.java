package net.mcreator.calvinhagermanmod.procedures;

public class DarkpoisinBlockAddedProcedure {
	public static void execute() {
	}
}
