
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.calvinhagermanmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.calvinhagermanmod.client.renderer.TopsecretagentRenderer;
import net.mcreator.calvinhagermanmod.client.renderer.DARKININGSLIMERenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CalvinHagermanModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(CalvinHagermanModModEntities.DARKSTAR.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(CalvinHagermanModModEntities.TOPSECRETAGENT.get(), TopsecretagentRenderer::new);
		event.registerEntityRenderer(CalvinHagermanModModEntities.DARKININGSLIME.get(), DARKININGSLIMERenderer::new);
	}
}
