
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.calvinhagermanmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.calvinhagermanmod.block.DarkpoisinBlock;
import net.mcreator.calvinhagermanmod.block.DarklavaBlock;
import net.mcreator.calvinhagermanmod.block.CALVINLANDSPortalBlock;
import net.mcreator.calvinhagermanmod.CalvinHagermanModMod;

public class CalvinHagermanModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, CalvinHagermanModMod.MODID);
	public static final RegistryObject<Block> DARKPOISIN = REGISTRY.register("darkpoisin", () -> new DarkpoisinBlock());
	public static final RegistryObject<Block> DARKLAVA = REGISTRY.register("darklava", () -> new DarklavaBlock());
	public static final RegistryObject<Block> CALVINLANDS_PORTAL = REGISTRY.register("calvinlands_portal", () -> new CALVINLANDSPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
