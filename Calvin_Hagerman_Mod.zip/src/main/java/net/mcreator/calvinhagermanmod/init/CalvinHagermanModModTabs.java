
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.calvinhagermanmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.calvinhagermanmod.CalvinHagermanModMod;

public class CalvinHagermanModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CalvinHagermanModMod.MODID);
	public static final RegistryObject<CreativeModeTab> CTAB = REGISTRY.register("ctab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.calvin_hagerman_mod.ctab")).icon(() -> new ItemStack(CalvinHagermanModModBlocks.DARKPOISIN.get())).displayItems((parameters, tabData) -> {
				tabData.accept(CalvinHagermanModModBlocks.DARKPOISIN.get().asItem());
				tabData.accept(CalvinHagermanModModBlocks.DARKLAVA.get().asItem());
				tabData.accept(CalvinHagermanModModItems.DARKORE.get());
				tabData.accept(CalvinHagermanModModItems.DARKWATERSWORD.get());
				tabData.accept(CalvinHagermanModModItems.DARKLAVAGRASS_HELMET.get());
				tabData.accept(CalvinHagermanModModItems.DARKLAVAGRASS_CHESTPLATE.get());
				tabData.accept(CalvinHagermanModModItems.DARKLAVAGRASS_LEGGINGS.get());
				tabData.accept(CalvinHagermanModModItems.DARKLAVAGRASS_BOOTS.get());
				tabData.accept(CalvinHagermanModModItems.EXTREMEARROWAXE.get());
				tabData.accept(CalvinHagermanModModItems.AWESOMEARMOR_HELMET.get());
				tabData.accept(CalvinHagermanModModItems.AWESOMEARMOR_CHESTPLATE.get());
				tabData.accept(CalvinHagermanModModItems.AWESOMEARMOR_LEGGINGS.get());
				tabData.accept(CalvinHagermanModModItems.AWESOMEARMOR_BOOTS.get());
				tabData.accept(CalvinHagermanModModItems.SPEEDSTAR.get());
				tabData.accept(CalvinHagermanModModItems.TOPSECRETAGENT_SPAWN_EGG.get());
				tabData.accept(CalvinHagermanModModItems.DARKININGSLIME_SPAWN_EGG.get());
				tabData.accept(CalvinHagermanModModItems.CALVINLANDS.get());
			}).withSearchBar().build());
}
