
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.calvinhagermanmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.calvinhagermanmod.item.SpeedstarItem;
import net.mcreator.calvinhagermanmod.item.ExtremearrowaxeItem;
import net.mcreator.calvinhagermanmod.item.DarkwaterswordItem;
import net.mcreator.calvinhagermanmod.item.DarkoreItem;
import net.mcreator.calvinhagermanmod.item.DarklavagrassItem;
import net.mcreator.calvinhagermanmod.item.CALVINLANDSItem;
import net.mcreator.calvinhagermanmod.item.AwesomearmorItem;
import net.mcreator.calvinhagermanmod.CalvinHagermanModMod;

public class CalvinHagermanModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, CalvinHagermanModMod.MODID);
	public static final RegistryObject<Item> DARKPOISIN = block(CalvinHagermanModModBlocks.DARKPOISIN);
	public static final RegistryObject<Item> DARKLAVA = block(CalvinHagermanModModBlocks.DARKLAVA);
	public static final RegistryObject<Item> DARKORE = REGISTRY.register("darkore", () -> new DarkoreItem());
	public static final RegistryObject<Item> DARKWATERSWORD = REGISTRY.register("darkwatersword", () -> new DarkwaterswordItem());
	public static final RegistryObject<Item> DARKLAVAGRASS_HELMET = REGISTRY.register("darklavagrass_helmet", () -> new DarklavagrassItem.Helmet());
	public static final RegistryObject<Item> DARKLAVAGRASS_CHESTPLATE = REGISTRY.register("darklavagrass_chestplate", () -> new DarklavagrassItem.Chestplate());
	public static final RegistryObject<Item> DARKLAVAGRASS_LEGGINGS = REGISTRY.register("darklavagrass_leggings", () -> new DarklavagrassItem.Leggings());
	public static final RegistryObject<Item> DARKLAVAGRASS_BOOTS = REGISTRY.register("darklavagrass_boots", () -> new DarklavagrassItem.Boots());
	public static final RegistryObject<Item> EXTREMEARROWAXE = REGISTRY.register("extremearrowaxe", () -> new ExtremearrowaxeItem());
	public static final RegistryObject<Item> AWESOMEARMOR_HELMET = REGISTRY.register("awesomearmor_helmet", () -> new AwesomearmorItem.Helmet());
	public static final RegistryObject<Item> AWESOMEARMOR_CHESTPLATE = REGISTRY.register("awesomearmor_chestplate", () -> new AwesomearmorItem.Chestplate());
	public static final RegistryObject<Item> AWESOMEARMOR_LEGGINGS = REGISTRY.register("awesomearmor_leggings", () -> new AwesomearmorItem.Leggings());
	public static final RegistryObject<Item> AWESOMEARMOR_BOOTS = REGISTRY.register("awesomearmor_boots", () -> new AwesomearmorItem.Boots());
	public static final RegistryObject<Item> SPEEDSTAR = REGISTRY.register("speedstar", () -> new SpeedstarItem());
	public static final RegistryObject<Item> TOPSECRETAGENT_SPAWN_EGG = REGISTRY.register("topsecretagent_spawn_egg", () -> new ForgeSpawnEggItem(CalvinHagermanModModEntities.TOPSECRETAGENT, -16777216, -10066330, new Item.Properties()));
	public static final RegistryObject<Item> DARKININGSLIME_SPAWN_EGG = REGISTRY.register("darkiningslime_spawn_egg", () -> new ForgeSpawnEggItem(CalvinHagermanModModEntities.DARKININGSLIME, -10040320, -16777216, new Item.Properties()));
	public static final RegistryObject<Item> CALVINLANDS = REGISTRY.register("calvinlands", () -> new CALVINLANDSItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
