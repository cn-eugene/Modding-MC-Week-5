
package net.mcreator.jamesmatsonmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class FireingitItem extends Item {
	public FireingitItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
