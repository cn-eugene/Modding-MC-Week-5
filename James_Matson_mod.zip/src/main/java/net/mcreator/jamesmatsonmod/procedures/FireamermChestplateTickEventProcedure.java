package net.mcreator.jamesmatsonmod.procedures;

public class FireamermChestplateTickEventProcedure {
	public static void execute() {
	}
}
