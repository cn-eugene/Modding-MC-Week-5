package net.mcreator.jamesmatsonmod.procedures;

public class FireamermHelmetTickEventProcedure {
	public static void execute() {
	}
}
