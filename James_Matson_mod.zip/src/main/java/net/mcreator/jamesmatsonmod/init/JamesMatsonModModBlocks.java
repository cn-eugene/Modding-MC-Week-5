
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jamesmatsonmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.jamesmatsonmod.block.WerdenPortalBlock;
import net.mcreator.jamesmatsonmod.block.V5PortalBlock;
import net.mcreator.jamesmatsonmod.block.TerkBlock;
import net.mcreator.jamesmatsonmod.block.TerfBlock;
import net.mcreator.jamesmatsonmod.block.FireoreBlock;
import net.mcreator.jamesmatsonmod.JamesMatsonModMod;

public class JamesMatsonModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, JamesMatsonModMod.MODID);
	public static final RegistryObject<Block> TERF = REGISTRY.register("terf", () -> new TerfBlock());
	public static final RegistryObject<Block> FIREORE = REGISTRY.register("fireore", () -> new FireoreBlock());
	public static final RegistryObject<Block> TERK = REGISTRY.register("terk", () -> new TerkBlock());
	public static final RegistryObject<Block> WERDEN_PORTAL = REGISTRY.register("werden_portal", () -> new WerdenPortalBlock());
	public static final RegistryObject<Block> V_5_PORTAL = REGISTRY.register("v_5_portal", () -> new V5PortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
