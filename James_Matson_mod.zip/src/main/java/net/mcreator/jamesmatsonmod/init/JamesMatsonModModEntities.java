
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jamesmatsonmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.jamesmatsonmod.entity.MotinEntityProjectile;
import net.mcreator.jamesmatsonmod.entity.MotinEntity;
import net.mcreator.jamesmatsonmod.entity.LightningEntity;
import net.mcreator.jamesmatsonmod.entity.K7Entity;
import net.mcreator.jamesmatsonmod.entity.Er76Entity;
import net.mcreator.jamesmatsonmod.entity.DertEntity;
import net.mcreator.jamesmatsonmod.JamesMatsonModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class JamesMatsonModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, JamesMatsonModMod.MODID);
	public static final RegistryObject<EntityType<LightningEntity>> LIGHTNING = register("lightning",
			EntityType.Builder.<LightningEntity>of(LightningEntity::new, MobCategory.MISC).setCustomClientFactory(LightningEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<K7Entity>> K_7 = register("k_7",
			EntityType.Builder.<K7Entity>of(K7Entity::new, MobCategory.MISC).setCustomClientFactory(K7Entity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<MotinEntity>> MOTIN = register("motin",
			EntityType.Builder.<MotinEntity>of(MotinEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(MotinEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<MotinEntityProjectile>> MOTIN_PROJECTILE = register("projectile_motin", EntityType.Builder.<MotinEntityProjectile>of(MotinEntityProjectile::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(1).setCustomClientFactory(MotinEntityProjectile::new).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<DertEntity>> DERT = register("dert",
			EntityType.Builder.<DertEntity>of(DertEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DertEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<Er76Entity>> ER_76 = register("er_76",
			EntityType.Builder.<Er76Entity>of(Er76Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(Er76Entity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			MotinEntity.init();
			DertEntity.init();
			Er76Entity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(MOTIN.get(), MotinEntity.createAttributes().build());
		event.put(DERT.get(), DertEntity.createAttributes().build());
		event.put(ER_76.get(), Er76Entity.createAttributes().build());
	}
}
