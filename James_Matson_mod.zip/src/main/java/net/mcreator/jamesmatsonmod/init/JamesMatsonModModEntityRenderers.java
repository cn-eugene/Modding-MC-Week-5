
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jamesmatsonmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.jamesmatsonmod.client.renderer.MotinRenderer;
import net.mcreator.jamesmatsonmod.client.renderer.Er76Renderer;
import net.mcreator.jamesmatsonmod.client.renderer.DertRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class JamesMatsonModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(JamesMatsonModModEntities.LIGHTNING.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(JamesMatsonModModEntities.K_7.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(JamesMatsonModModEntities.MOTIN.get(), MotinRenderer::new);
		event.registerEntityRenderer(JamesMatsonModModEntities.MOTIN_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(JamesMatsonModModEntities.DERT.get(), DertRenderer::new);
		event.registerEntityRenderer(JamesMatsonModModEntities.ER_76.get(), Er76Renderer::new);
	}
}
