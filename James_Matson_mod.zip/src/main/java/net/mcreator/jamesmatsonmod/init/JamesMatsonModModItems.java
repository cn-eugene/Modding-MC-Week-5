
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jamesmatsonmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.jamesmatsonmod.item.WerdenItem;
import net.mcreator.jamesmatsonmod.item.WeordernstowItem;
import net.mcreator.jamesmatsonmod.item.V5Item;
import net.mcreator.jamesmatsonmod.item.FopopItem;
import net.mcreator.jamesmatsonmod.item.FiresowedItem;
import net.mcreator.jamesmatsonmod.item.FireingitItem;
import net.mcreator.jamesmatsonmod.item.FireamermItem;
import net.mcreator.jamesmatsonmod.JamesMatsonModMod;

public class JamesMatsonModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, JamesMatsonModMod.MODID);
	public static final RegistryObject<Item> TERF = block(JamesMatsonModModBlocks.TERF);
	public static final RegistryObject<Item> FIREORE = block(JamesMatsonModModBlocks.FIREORE);
	public static final RegistryObject<Item> FIREINGIT = REGISTRY.register("fireingit", () -> new FireingitItem());
	public static final RegistryObject<Item> TERK = block(JamesMatsonModModBlocks.TERK);
	public static final RegistryObject<Item> FIRESOWED = REGISTRY.register("firesowed", () -> new FiresowedItem());
	public static final RegistryObject<Item> WERDEN = REGISTRY.register("werden", () -> new WerdenItem());
	public static final RegistryObject<Item> FIREAMERM_HELMET = REGISTRY.register("fireamerm_helmet", () -> new FireamermItem.Helmet());
	public static final RegistryObject<Item> FIREAMERM_CHESTPLATE = REGISTRY.register("fireamerm_chestplate", () -> new FireamermItem.Chestplate());
	public static final RegistryObject<Item> FIREAMERM_LEGGINGS = REGISTRY.register("fireamerm_leggings", () -> new FireamermItem.Leggings());
	public static final RegistryObject<Item> FIREAMERM_BOOTS = REGISTRY.register("fireamerm_boots", () -> new FireamermItem.Boots());
	public static final RegistryObject<Item> FOPOP = REGISTRY.register("fopop", () -> new FopopItem());
	public static final RegistryObject<Item> WEORDERNSTOW = REGISTRY.register("weordernstow", () -> new WeordernstowItem());
	public static final RegistryObject<Item> MOTIN_SPAWN_EGG = REGISTRY.register("motin_spawn_egg", () -> new ForgeSpawnEggItem(JamesMatsonModModEntities.MOTIN, -256, -3407872, new Item.Properties()));
	public static final RegistryObject<Item> V_5 = REGISTRY.register("v_5", () -> new V5Item());
	public static final RegistryObject<Item> DERT_SPAWN_EGG = REGISTRY.register("dert_spawn_egg", () -> new ForgeSpawnEggItem(JamesMatsonModModEntities.DERT, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> ER_76_SPAWN_EGG = REGISTRY.register("er_76_spawn_egg", () -> new ForgeSpawnEggItem(JamesMatsonModModEntities.ER_76, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
