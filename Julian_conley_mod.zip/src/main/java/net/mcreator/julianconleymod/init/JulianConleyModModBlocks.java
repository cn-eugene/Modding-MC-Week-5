
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.julianconleymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.julianconleymod.block.KillbrickBlock;
import net.mcreator.julianconleymod.block.DiffulsultBlock;
import net.mcreator.julianconleymod.JulianConleyModMod;

public class JulianConleyModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, JulianConleyModMod.MODID);
	public static final RegistryObject<Block> KILLBRICK = REGISTRY.register("killbrick", () -> new KillbrickBlock());
	public static final RegistryObject<Block> DIFFULSULT = REGISTRY.register("diffulsult", () -> new DiffulsultBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
