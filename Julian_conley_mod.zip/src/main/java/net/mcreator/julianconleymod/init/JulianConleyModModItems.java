
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.julianconleymod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.julianconleymod.item.OwnertoolItem;
import net.mcreator.julianconleymod.item.ForrbidenstarItem;
import net.mcreator.julianconleymod.item.EasyarmorItem;
import net.mcreator.julianconleymod.item.Diffingotv2Item;
import net.mcreator.julianconleymod.item.DiffbandItem;
import net.mcreator.julianconleymod.item.DiffIngotItem;
import net.mcreator.julianconleymod.JulianConleyModMod;

public class JulianConleyModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, JulianConleyModMod.MODID);
	public static final RegistryObject<Item> KILLBRICK = block(JulianConleyModModBlocks.KILLBRICK);
	public static final RegistryObject<Item> DIFFULSULT = block(JulianConleyModModBlocks.DIFFULSULT);
	public static final RegistryObject<Item> DIFF_INGOT = REGISTRY.register("diff_ingot", () -> new DiffIngotItem());
	public static final RegistryObject<Item> DIFFINGOTV_2 = REGISTRY.register("diffingotv_2", () -> new Diffingotv2Item());
	public static final RegistryObject<Item> DIFFBAND = REGISTRY.register("diffband", () -> new DiffbandItem());
	public static final RegistryObject<Item> EASYARMOR_HELMET = REGISTRY.register("easyarmor_helmet", () -> new EasyarmorItem.Helmet());
	public static final RegistryObject<Item> EASYARMOR_CHESTPLATE = REGISTRY.register("easyarmor_chestplate", () -> new EasyarmorItem.Chestplate());
	public static final RegistryObject<Item> EASYARMOR_LEGGINGS = REGISTRY.register("easyarmor_leggings", () -> new EasyarmorItem.Leggings());
	public static final RegistryObject<Item> EASYARMOR_BOOTS = REGISTRY.register("easyarmor_boots", () -> new EasyarmorItem.Boots());
	public static final RegistryObject<Item> OWNERTOOL = REGISTRY.register("ownertool", () -> new OwnertoolItem());
	public static final RegistryObject<Item> FORRBIDENSTAR = REGISTRY.register("forrbidenstar", () -> new ForrbidenstarItem());
	public static final RegistryObject<Item> TOTORIAL_SPAWN_EGG = REGISTRY.register("totorial_spawn_egg", () -> new ForgeSpawnEggItem(JulianConleyModModEntities.TOTORIAL, -16751104, -16777216, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
