
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.julianconleymod.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.julianconleymod.JulianConleyModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class JulianConleyModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JulianConleyModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(JulianConleyModModItems.DIFFBAND.get());
			tabData.accept(JulianConleyModModItems.EASYARMOR_HELMET.get());
			tabData.accept(JulianConleyModModItems.EASYARMOR_CHESTPLATE.get());
			tabData.accept(JulianConleyModModItems.EASYARMOR_LEGGINGS.get());
			tabData.accept(JulianConleyModModItems.EASYARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(JulianConleyModModItems.TOTORIAL_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(JulianConleyModModItems.DIFF_INGOT.get());
			tabData.accept(JulianConleyModModItems.DIFFINGOTV_2.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(JulianConleyModModBlocks.KILLBRICK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(JulianConleyModModItems.OWNERTOOL.get());
		}
	}
}
