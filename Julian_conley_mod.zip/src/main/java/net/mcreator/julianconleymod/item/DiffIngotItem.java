
package net.mcreator.julianconleymod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class DiffIngotItem extends Item {
	public DiffIngotItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
