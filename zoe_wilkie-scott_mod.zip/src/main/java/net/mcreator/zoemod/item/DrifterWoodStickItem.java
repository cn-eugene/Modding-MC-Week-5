
package net.mcreator.zoemod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class DrifterWoodStickItem extends Item {
	public DrifterWoodStickItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.RARE));
	}
}
