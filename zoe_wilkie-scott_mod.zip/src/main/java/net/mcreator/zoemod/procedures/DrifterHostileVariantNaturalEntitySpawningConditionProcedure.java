package net.mcreator.zoemod.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.zoemod.init.ZoeModModEntities;
import net.mcreator.zoemod.entity.DrifterEntity;

import java.util.Comparator;

public class DrifterHostileVariantNaturalEntitySpawningConditionProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		Entity Drifter = null;
		for (int index0 = 0; index0 < 5; index0++) {
			Drifter = (Entity) world.getEntitiesOfClass(DrifterEntity.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null);
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = ZoeModModEntities.DRIFTER_HOSTILE_VARIANT.get().spawn(_level, BlockPos.containing(Drifter.getZ(), Drifter.getY(), Drifter.getX()), MobSpawnType.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setDeltaMovement(0, 0, 0);
				}
			}
			if (!Drifter.level().isClientSide())
				Drifter.discard();
		}
	}
}
