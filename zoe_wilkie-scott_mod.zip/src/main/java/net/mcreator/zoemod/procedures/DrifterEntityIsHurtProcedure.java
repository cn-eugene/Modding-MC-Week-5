package net.mcreator.zoemod.procedures;

import net.minecraft.world.entity.Entity;

public class DrifterEntityIsHurtProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setInvisible(true);
	}
}
