
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zoemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.bus.api.IEventBus;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.zoemod.item.PsychedelicRealmItem;
import net.mcreator.zoemod.item.PsychedelicDrifterEyesItem;
import net.mcreator.zoemod.item.PsychedelicArmorItem;
import net.mcreator.zoemod.item.GlowshroomHeadItem;
import net.mcreator.zoemod.item.GlowshroomCrossbowItem;
import net.mcreator.zoemod.item.GlowShroomArmorItem;
import net.mcreator.zoemod.item.DrifterWoodStickItem;
import net.mcreator.zoemod.item.DrifterHandItem;
import net.mcreator.zoemod.item.DrifterDimensionItem;
import net.mcreator.zoemod.item.DrifterArmorItem;
import net.mcreator.zoemod.item.DeadDrifterTotemItem;
import net.mcreator.zoemod.item.CrystalyzedSapItem;
import net.mcreator.zoemod.item.CrystalizedSapSwordItem;
import net.mcreator.zoemod.item.CrystalizedSapShovelItem;
import net.mcreator.zoemod.item.CrystalizedSapPickaxeItem;
import net.mcreator.zoemod.item.CrystalizedSapAxeItem;
import net.mcreator.zoemod.ZoeModMod;

public class ZoeModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, ZoeModMod.MODID);
	public static final DeferredHolder<Item, Item> DRIFTER_WOOD = block(ZoeModModBlocks.DRIFTER_WOOD);
	public static final DeferredHolder<Item, Item> CRYSTALYZED_SAP = REGISTRY.register("crystalyzed_sap", () -> new CrystalyzedSapItem());
	public static final DeferredHolder<Item, Item> SAP_ORE = block(ZoeModModBlocks.SAP_ORE);
	public static final DeferredHolder<Item, Item> DRIFT_WOOD_LEAVES = block(ZoeModModBlocks.DRIFT_WOOD_LEAVES);
	public static final DeferredHolder<Item, Item> GLOWSHROOM_HEAD = REGISTRY.register("glowshroom_head", () -> new GlowshroomHeadItem());
	public static final DeferredHolder<Item, Item> GLOWSHROOM = block(ZoeModModBlocks.GLOWSHROOM);
	public static final DeferredHolder<Item, Item> CRYSTALIZED_SAP_PICKAXE = REGISTRY.register("crystalized_sap_pickaxe", () -> new CrystalizedSapPickaxeItem());
	public static final DeferredHolder<Item, Item> CRYSTALIZED_SAP_AXE = REGISTRY.register("crystalized_sap_axe", () -> new CrystalizedSapAxeItem());
	public static final DeferredHolder<Item, Item> CRYSTALIZED_SAP_SHOVEL = REGISTRY.register("crystalized_sap_shovel", () -> new CrystalizedSapShovelItem());
	public static final DeferredHolder<Item, Item> CRYSTALIZED_SAP_SWORD = REGISTRY.register("crystalized_sap_sword", () -> new CrystalizedSapSwordItem());
	public static final DeferredHolder<Item, Item> DRIFTER_WOOD_STICK = REGISTRY.register("drifter_wood_stick", () -> new DrifterWoodStickItem());
	public static final DeferredHolder<Item, Item> DRIFTER_VINES = block(ZoeModModBlocks.DRIFTER_VINES);
	public static final DeferredHolder<Item, Item> DRIFTER_DIMENSION = REGISTRY.register("drifter_dimension", () -> new DrifterDimensionItem());
	public static final DeferredHolder<Item, Item> DRIFTER_SPAWN_EGG = REGISTRY.register("drifter_spawn_egg", () -> new DeferredSpawnEggItem(ZoeModModEntities.DRIFTER, -16769764, -16751002, new Item.Properties()));
	public static final DeferredHolder<Item, Item> GLOW_SHROOM_ARMOR_HELMET = REGISTRY.register("glow_shroom_armor_helmet", () -> new GlowShroomArmorItem.Helmet());
	public static final DeferredHolder<Item, Item> GLOW_SHROOM_ARMOR_CHESTPLATE = REGISTRY.register("glow_shroom_armor_chestplate", () -> new GlowShroomArmorItem.Chestplate());
	public static final DeferredHolder<Item, Item> GLOW_SHROOM_ARMOR_LEGGINGS = REGISTRY.register("glow_shroom_armor_leggings", () -> new GlowShroomArmorItem.Leggings());
	public static final DeferredHolder<Item, Item> GLOW_SHROOM_ARMOR_BOOTS = REGISTRY.register("glow_shroom_armor_boots", () -> new GlowShroomArmorItem.Boots());
	public static final DeferredHolder<Item, Item> DEAD_DRIFTER_TOTEM = REGISTRY.register("dead_drifter_totem", () -> new DeadDrifterTotemItem());
	public static final DeferredHolder<Item, Item> DRIFTWOOD_PLANKS = block(ZoeModModBlocks.DRIFTWOOD_PLANKS);
	public static final DeferredHolder<Item, Item> DRIFTER_HOSTILE_VARIANT_SPAWN_EGG = REGISTRY.register("drifter_hostile_variant_spawn_egg",
			() -> new DeferredSpawnEggItem(ZoeModModEntities.DRIFTER_HOSTILE_VARIANT, -16763601, -16770807, new Item.Properties()));
	public static final DeferredHolder<Item, Item> DRIFTER_HAND = REGISTRY.register("drifter_hand", () -> new DrifterHandItem());
	public static final DeferredHolder<Item, Item> GLOWSHROOM_CROSSBOW = REGISTRY.register("glowshroom_crossbow", () -> new GlowshroomCrossbowItem());
	public static final DeferredHolder<Item, Item> GLOW_SHROOMER_SPAWN_EGG = REGISTRY.register("glow_shroomer_spawn_egg", () -> new DeferredSpawnEggItem(ZoeModModEntities.GLOW_SHROOMER, -16764365, -4456467, new Item.Properties()));
	public static final DeferredHolder<Item, Item> DRIFTER_ARMOR_HELMET = REGISTRY.register("drifter_armor_helmet", () -> new DrifterArmorItem.Helmet());
	public static final DeferredHolder<Item, Item> DRIFTER_ARMOR_CHESTPLATE = REGISTRY.register("drifter_armor_chestplate", () -> new DrifterArmorItem.Chestplate());
	public static final DeferredHolder<Item, Item> DRIFTER_ARMOR_LEGGINGS = REGISTRY.register("drifter_armor_leggings", () -> new DrifterArmorItem.Leggings());
	public static final DeferredHolder<Item, Item> DRIFTER_ARMOR_BOOTS = REGISTRY.register("drifter_armor_boots", () -> new DrifterArmorItem.Boots());
	public static final DeferredHolder<Item, Item> PSYCHEDELIC_LOG = block(ZoeModModBlocks.PSYCHEDELIC_LOG);
	public static final DeferredHolder<Item, Item> PSYCHEDELIC_LEAVES = block(ZoeModModBlocks.PSYCHEDELIC_LEAVES);
	public static final DeferredHolder<Item, Item> PSYCHEDELIC_REALM = REGISTRY.register("psychedelic_realm", () -> new PsychedelicRealmItem());
	public static final DeferredHolder<Item, Item> EYE_SHROOM = block(ZoeModModBlocks.EYE_SHROOM);
	public static final DeferredHolder<Item, Item> PSYCHEDELIC_ARMOR_HELMET = REGISTRY.register("psychedelic_armor_helmet", () -> new PsychedelicArmorItem.Helmet());
	public static final DeferredHolder<Item, Item> PSYCHEDELIC_ARMOR_CHESTPLATE = REGISTRY.register("psychedelic_armor_chestplate", () -> new PsychedelicArmorItem.Chestplate());
	public static final DeferredHolder<Item, Item> PSYCHEDELIC_ARMOR_LEGGINGS = REGISTRY.register("psychedelic_armor_leggings", () -> new PsychedelicArmorItem.Leggings());
	public static final DeferredHolder<Item, Item> PSYCHEDELIC_ARMOR_BOOTS = REGISTRY.register("psychedelic_armor_boots", () -> new PsychedelicArmorItem.Boots());
	public static final DeferredHolder<Item, Item> PSYCHEDELIC_DRIFTER_SPAWN_EGG = REGISTRY.register("psychedelic_drifter_spawn_egg", () -> new DeferredSpawnEggItem(ZoeModModEntities.PSYCHEDELIC_DRIFTER, -5898496, -8355712, new Item.Properties()));
	public static final DeferredHolder<Item, Item> PSYCHEDELIC_DRIFTER_EYES = REGISTRY.register("psychedelic_drifter_eyes", () -> new PsychedelicDrifterEyesItem());

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}

	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
