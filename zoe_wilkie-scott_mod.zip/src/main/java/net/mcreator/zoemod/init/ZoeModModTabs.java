
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zoemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.zoemod.ZoeModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ZoeModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ZoeModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(ZoeModModBlocks.DRIFTWOOD_PLANKS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(ZoeModModItems.GLOW_SHROOM_ARMOR_HELMET.get());
			tabData.accept(ZoeModModItems.GLOW_SHROOM_ARMOR_CHESTPLATE.get());
			tabData.accept(ZoeModModItems.GLOW_SHROOM_ARMOR_LEGGINGS.get());
			tabData.accept(ZoeModModItems.GLOW_SHROOM_ARMOR_BOOTS.get());
			tabData.accept(ZoeModModItems.GLOWSHROOM_CROSSBOW.get());
			tabData.accept(ZoeModModItems.DRIFTER_ARMOR_HELMET.get());
			tabData.accept(ZoeModModItems.DRIFTER_ARMOR_CHESTPLATE.get());
			tabData.accept(ZoeModModItems.DRIFTER_ARMOR_LEGGINGS.get());
			tabData.accept(ZoeModModItems.DRIFTER_ARMOR_BOOTS.get());
			tabData.accept(ZoeModModItems.PSYCHEDELIC_ARMOR_HELMET.get());
			tabData.accept(ZoeModModItems.PSYCHEDELIC_ARMOR_CHESTPLATE.get());
			tabData.accept(ZoeModModItems.PSYCHEDELIC_ARMOR_LEGGINGS.get());
			tabData.accept(ZoeModModItems.PSYCHEDELIC_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(ZoeModModItems.DRIFTER_SPAWN_EGG.get());
			tabData.accept(ZoeModModItems.GLOW_SHROOMER_SPAWN_EGG.get());
			tabData.accept(ZoeModModItems.PSYCHEDELIC_DRIFTER_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(ZoeModModItems.CRYSTALYZED_SAP.get());
			tabData.accept(ZoeModModItems.GLOWSHROOM_HEAD.get());
			tabData.accept(ZoeModModItems.DEAD_DRIFTER_TOTEM.get());
			tabData.accept(ZoeModModItems.DRIFTER_HAND.get());
			tabData.accept(ZoeModModItems.PSYCHEDELIC_REALM.get());
			tabData.accept(ZoeModModItems.PSYCHEDELIC_DRIFTER_EYES.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(ZoeModModBlocks.DRIFTER_WOOD.get().asItem());
			tabData.accept(ZoeModModBlocks.SAP_ORE.get().asItem());
			tabData.accept(ZoeModModBlocks.DRIFT_WOOD_LEAVES.get().asItem());
			tabData.accept(ZoeModModBlocks.GLOWSHROOM.get().asItem());
			tabData.accept(ZoeModModBlocks.DRIFTER_VINES.get().asItem());
			tabData.accept(ZoeModModBlocks.PSYCHEDELIC_LOG.get().asItem());
			tabData.accept(ZoeModModBlocks.EYE_SHROOM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ZoeModModItems.CRYSTALIZED_SAP_PICKAXE.get());
			tabData.accept(ZoeModModItems.CRYSTALIZED_SAP_AXE.get());
			tabData.accept(ZoeModModItems.CRYSTALIZED_SAP_SHOVEL.get());
			tabData.accept(ZoeModModItems.CRYSTALIZED_SAP_SWORD.get());
			tabData.accept(ZoeModModItems.DRIFTER_DIMENSION.get());
		}
	}
}
