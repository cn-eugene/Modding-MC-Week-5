
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zoemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.zoemod.entity.PsychedelicDrifterEntity;
import net.mcreator.zoemod.entity.GlowShroomerEntity;
import net.mcreator.zoemod.entity.DrifterHostileVariantEntity;
import net.mcreator.zoemod.entity.DrifterEntity;
import net.mcreator.zoemod.entity.DeadDrifterTotemThrowerEntity;
import net.mcreator.zoemod.ZoeModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ZoeModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, ZoeModMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<DrifterEntity>> DRIFTER = register("drifter",
			EntityType.Builder.<DrifterEntity>of(DrifterEntity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<DrifterHostileVariantEntity>> DRIFTER_HOSTILE_VARIANT = register("drifter_hostile_variant",
			EntityType.Builder.<DrifterHostileVariantEntity>of(DrifterHostileVariantEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<DeadDrifterTotemThrowerEntity>> DEAD_DRIFTER_TOTEM_THROWER = register("dead_drifter_totem_thrower",
			EntityType.Builder.<DeadDrifterTotemThrowerEntity>of(DeadDrifterTotemThrowerEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<GlowShroomerEntity>> GLOW_SHROOMER = register("glow_shroomer",
			EntityType.Builder.<GlowShroomerEntity>of(GlowShroomerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<PsychedelicDrifterEntity>> PSYCHEDELIC_DRIFTER = register("psychedelic_drifter",
			EntityType.Builder.<PsychedelicDrifterEntity>of(PsychedelicDrifterEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));

	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			DrifterEntity.init();
			DrifterHostileVariantEntity.init();
			GlowShroomerEntity.init();
			PsychedelicDrifterEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(DRIFTER.get(), DrifterEntity.createAttributes().build());
		event.put(DRIFTER_HOSTILE_VARIANT.get(), DrifterHostileVariantEntity.createAttributes().build());
		event.put(GLOW_SHROOMER.get(), GlowShroomerEntity.createAttributes().build());
		event.put(PSYCHEDELIC_DRIFTER.get(), PsychedelicDrifterEntity.createAttributes().build());
	}
}
