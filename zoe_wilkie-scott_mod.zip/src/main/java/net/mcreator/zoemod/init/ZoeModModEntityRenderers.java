
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zoemod.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.zoemod.client.renderer.PsychedelicDrifterRenderer;
import net.mcreator.zoemod.client.renderer.GlowShroomerRenderer;
import net.mcreator.zoemod.client.renderer.DrifterRenderer;
import net.mcreator.zoemod.client.renderer.DrifterHostileVariantRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ZoeModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(ZoeModModEntities.DRIFTER.get(), DrifterRenderer::new);
		event.registerEntityRenderer(ZoeModModEntities.DRIFTER_HOSTILE_VARIANT.get(), DrifterHostileVariantRenderer::new);
		event.registerEntityRenderer(ZoeModModEntities.DEAD_DRIFTER_TOTEM_THROWER.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ZoeModModEntities.GLOW_SHROOMER.get(), GlowShroomerRenderer::new);
		event.registerEntityRenderer(ZoeModModEntities.PSYCHEDELIC_DRIFTER.get(), PsychedelicDrifterRenderer::new);
	}
}
