
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zoemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.zoemod.block.SapOreBlock;
import net.mcreator.zoemod.block.PsychedelicRealmPortalBlock;
import net.mcreator.zoemod.block.PsychedelicLogBlock;
import net.mcreator.zoemod.block.PsychedelicLeavesBlock;
import net.mcreator.zoemod.block.GlowshroomBlock;
import net.mcreator.zoemod.block.EyeShroomBlock;
import net.mcreator.zoemod.block.DriftwoodPlanksBlock;
import net.mcreator.zoemod.block.DrifterWoodBlock;
import net.mcreator.zoemod.block.DrifterVinesBlock;
import net.mcreator.zoemod.block.DrifterDimensionPortalBlock;
import net.mcreator.zoemod.block.DriftWoodLeavesBlock;
import net.mcreator.zoemod.ZoeModMod;

public class ZoeModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, ZoeModMod.MODID);
	public static final DeferredHolder<Block, Block> DRIFTER_WOOD = REGISTRY.register("drifter_wood", () -> new DrifterWoodBlock());
	public static final DeferredHolder<Block, Block> SAP_ORE = REGISTRY.register("sap_ore", () -> new SapOreBlock());
	public static final DeferredHolder<Block, Block> DRIFT_WOOD_LEAVES = REGISTRY.register("drift_wood_leaves", () -> new DriftWoodLeavesBlock());
	public static final DeferredHolder<Block, Block> GLOWSHROOM = REGISTRY.register("glowshroom", () -> new GlowshroomBlock());
	public static final DeferredHolder<Block, Block> DRIFTER_VINES = REGISTRY.register("drifter_vines", () -> new DrifterVinesBlock());
	public static final DeferredHolder<Block, Block> DRIFTER_DIMENSION_PORTAL = REGISTRY.register("drifter_dimension_portal", () -> new DrifterDimensionPortalBlock());
	public static final DeferredHolder<Block, Block> DRIFTWOOD_PLANKS = REGISTRY.register("driftwood_planks", () -> new DriftwoodPlanksBlock());
	public static final DeferredHolder<Block, Block> PSYCHEDELIC_LOG = REGISTRY.register("psychedelic_log", () -> new PsychedelicLogBlock());
	public static final DeferredHolder<Block, Block> PSYCHEDELIC_LEAVES = REGISTRY.register("psychedelic_leaves", () -> new PsychedelicLeavesBlock());
	public static final DeferredHolder<Block, Block> PSYCHEDELIC_REALM_PORTAL = REGISTRY.register("psychedelic_realm_portal", () -> new PsychedelicRealmPortalBlock());
	public static final DeferredHolder<Block, Block> EYE_SHROOM = REGISTRY.register("eye_shroom", () -> new EyeShroomBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
