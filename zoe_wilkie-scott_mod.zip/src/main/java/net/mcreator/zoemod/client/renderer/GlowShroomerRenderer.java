
package net.mcreator.zoemod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.zoemod.entity.GlowShroomerEntity;

public class GlowShroomerRenderer extends HumanoidMobRenderer<GlowShroomerEntity, HumanoidModel<GlowShroomerEntity>> {
	public GlowShroomerRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(GlowShroomerEntity entity) {
		return new ResourceLocation("zoe_mod:textures/entities/38df456d7a355600de20e39372749eb18ac4d117.png");
	}
}
