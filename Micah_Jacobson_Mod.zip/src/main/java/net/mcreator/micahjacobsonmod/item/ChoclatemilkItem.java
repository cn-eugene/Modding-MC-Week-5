
package net.mcreator.micahjacobsonmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.micahjacobsonmod.init.MicahJacobsonModModFluids;

public class ChoclatemilkItem extends BucketItem {
	public ChoclatemilkItem() {
		super(MicahJacobsonModModFluids.CHOCLATEMILK, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.EPIC));
	}
}
