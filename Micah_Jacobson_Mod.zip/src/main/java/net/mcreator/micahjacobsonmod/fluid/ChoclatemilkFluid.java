
package net.mcreator.micahjacobsonmod.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.BlockPos;

import net.mcreator.micahjacobsonmod.procedures.DefeatcommandProcedure;
import net.mcreator.micahjacobsonmod.init.MicahJacobsonModModItems;
import net.mcreator.micahjacobsonmod.init.MicahJacobsonModModFluids;
import net.mcreator.micahjacobsonmod.init.MicahJacobsonModModFluidTypes;
import net.mcreator.micahjacobsonmod.init.MicahJacobsonModModBlocks;

public abstract class ChoclatemilkFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> MicahJacobsonModModFluidTypes.CHOCLATEMILK_TYPE.get(), () -> MicahJacobsonModModFluids.CHOCLATEMILK.get(),
			() -> MicahJacobsonModModFluids.FLOWING_CHOCLATEMILK.get()).explosionResistance(1234.5f).tickRate(100).levelDecreasePerBlock(5).slopeFindDistance(10).bucket(() -> MicahJacobsonModModItems.CHOCLATEMILK_BUCKET.get())
			.block(() -> (LiquidBlock) MicahJacobsonModModBlocks.CHOCLATEMILK.get());

	private ChoclatemilkFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.SPLASH;
	}

	@Override
	protected void beforeDestroyingBlock(LevelAccessor world, BlockPos pos, BlockState blockstate) {
		DefeatcommandProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	public static class Source extends ChoclatemilkFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends ChoclatemilkFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
