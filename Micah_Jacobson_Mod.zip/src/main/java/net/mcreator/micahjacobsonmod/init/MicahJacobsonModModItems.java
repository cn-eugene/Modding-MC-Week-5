
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.micahjacobsonmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.micahjacobsonmod.item.SusarmorItem;
import net.mcreator.micahjacobsonmod.item.KnifeItem;
import net.mcreator.micahjacobsonmod.item.GunItem;
import net.mcreator.micahjacobsonmod.item.ChoclatemilkItem;
import net.mcreator.micahjacobsonmod.item.Bullet1Item;
import net.mcreator.micahjacobsonmod.MicahJacobsonModMod;

public class MicahJacobsonModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MicahJacobsonModMod.MODID);
	public static final RegistryObject<Item> O_PGRASSBLOCK = block(MicahJacobsonModModBlocks.O_PGRASSBLOCK);
	public static final RegistryObject<Item> RAINBOWORE = block(MicahJacobsonModModBlocks.RAINBOWORE);
	public static final RegistryObject<Item> SUSARMOR_HELMET = REGISTRY.register("susarmor_helmet", () -> new SusarmorItem.Helmet());
	public static final RegistryObject<Item> SUSARMOR_CHESTPLATE = REGISTRY.register("susarmor_chestplate", () -> new SusarmorItem.Chestplate());
	public static final RegistryObject<Item> SUSARMOR_LEGGINGS = REGISTRY.register("susarmor_leggings", () -> new SusarmorItem.Leggings());
	public static final RegistryObject<Item> SUSARMOR_BOOTS = REGISTRY.register("susarmor_boots", () -> new SusarmorItem.Boots());
	public static final RegistryObject<Item> GUN = REGISTRY.register("gun", () -> new GunItem());
	public static final RegistryObject<Item> BULLET_1 = REGISTRY.register("bullet_1", () -> new Bullet1Item());
	public static final RegistryObject<Item> CAMMAN_18_SPAWN_EGG = REGISTRY.register("camman_18_spawn_egg", () -> new ForgeSpawnEggItem(MicahJacobsonModModEntities.CAMMAN_18, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> CHOCLATEMILK_BUCKET = REGISTRY.register("choclatemilk_bucket", () -> new ChoclatemilkItem());
	public static final RegistryObject<Item> KNIFE = REGISTRY.register("knife", () -> new KnifeItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
