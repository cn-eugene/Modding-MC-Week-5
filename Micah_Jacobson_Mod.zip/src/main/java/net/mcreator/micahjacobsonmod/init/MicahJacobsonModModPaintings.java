
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.micahjacobsonmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.entity.decoration.PaintingVariant;

import net.mcreator.micahjacobsonmod.MicahJacobsonModMod;

public class MicahJacobsonModModPaintings {
	public static final DeferredRegister<PaintingVariant> REGISTRY = DeferredRegister.create(ForgeRegistries.PAINTING_VARIANTS, MicahJacobsonModMod.MODID);
	public static final RegistryObject<PaintingVariant> MRBEASTPAINTING = REGISTRY.register("mrbeastpainting", () -> new PaintingVariant(16, 16));
}
