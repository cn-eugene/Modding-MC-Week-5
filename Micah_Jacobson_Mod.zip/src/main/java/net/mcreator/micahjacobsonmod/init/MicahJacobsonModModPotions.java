
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.micahjacobsonmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.micahjacobsonmod.MicahJacobsonModMod;

public class MicahJacobsonModModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, MicahJacobsonModMod.MODID);
	public static final RegistryObject<Potion> SHAPESHIFTERPOTION = REGISTRY.register("shapeshifterpotion", () -> new Potion(new MobEffectInstance(MobEffects.INVISIBILITY, 12345, 123, true, true)));
}
