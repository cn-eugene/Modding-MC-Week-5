
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.micahjacobsonmod.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.micahjacobsonmod.MicahJacobsonModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MicahJacobsonModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MicahJacobsonModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(MicahJacobsonModModItems.SUSARMOR_HELMET.get());
			tabData.accept(MicahJacobsonModModItems.SUSARMOR_CHESTPLATE.get());
			tabData.accept(MicahJacobsonModModItems.SUSARMOR_LEGGINGS.get());
			tabData.accept(MicahJacobsonModModItems.SUSARMOR_BOOTS.get());
			tabData.accept(MicahJacobsonModModItems.GUN.get());
			tabData.accept(MicahJacobsonModModItems.BULLET_1.get());
			tabData.accept(MicahJacobsonModModItems.KNIFE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(MicahJacobsonModModItems.CAMMAN_18_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(MicahJacobsonModModBlocks.RAINBOWORE.get().asItem());
			tabData.accept(MicahJacobsonModModBlocks.O_PGRASSBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(MicahJacobsonModModItems.CHOCLATEMILK_BUCKET.get());
		}
	}
}
